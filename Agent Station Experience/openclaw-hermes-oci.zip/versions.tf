terraform {
  required_version = ">= 1.5.0"

  required_providers {
    oci = {
      source  = "oracle/oci"
      version = ">= 7.9.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.6.0"
    }
    tls = {
      source  = "hashicorp/tls"
      version = ">= 4.0.0"
    }
    null = {
      source  = "hashicorp/null"
      version = ">= 3.2.0"
    }
  }
}

# Intentionally no API key here. OCI Resource Manager uses instance principal,
# while local Terraform can use the caller's configured auth. The region is an
# explicit variable because Resource Manager does not infer it for this provider.
provider "oci" {
  region = var.region
}
