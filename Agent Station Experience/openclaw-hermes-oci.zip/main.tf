resource "random_id" "suffix" {
  byte_length = 3
}

resource "tls_private_key" "ssh" {
  algorithm = "ED25519"
}

resource "random_string" "openclaw_gateway_token" {
  length  = 48
  upper   = true
  lower   = true
  numeric = true
  special = false
}

locals {
  selected_app = lower(var.app)
  name_prefix  = "chat-${random_id.suffix.hex}"
  user_ssh_key = trimspace(var.ssh_public_key)
  ssh_key      = trimspace(join("\n", compact([local.user_ssh_key, tls_private_key.ssh.public_key_openssh])))

  shape_priority = ["VM.Standard.E5.Flex", "VM.Standard.E6.Flex"]

  ad_supported_shapes = [
    for ad_index, ad in data.oci_identity_availability_domains.ads.availability_domains : [
      for wanted_shape in local.shape_priority : wanted_shape
      if contains([for shape in data.oci_core_shapes.by_ad[ad_index].shapes : shape.name], wanted_shape)
    ]
  ]

  ad_capacity_inputs = [
    for ad_index, ad in data.oci_identity_availability_domains.ads.availability_domains : {
      availability_domain = ad.name
      shapes              = local.ad_supported_shapes[ad_index]
    } if length(local.ad_supported_shapes[ad_index]) > 0
  ]

  capacity_pairs = flatten([
    for report in oci_core_compute_capacity_report.by_ad : [
      for shape in report.shape_availabilities : {
        availability_domain = report.availability_domain
        shape_name          = shape.instance_shape
        available_count     = try(tonumber(shape.available_count), 0)
        availability_status = upper(tostring(try(shape.availability_status, "")))
      } if contains(local.shape_priority, shape.instance_shape)
    ]
  ])

  available_capacity_pairs = [
    for pair in local.capacity_pairs : pair
    if pair.available_count > 0 || contains(["AVAILABLE", "SUFFICIENT"], pair.availability_status)
  ]

  e5_available_pairs   = [for pair in local.available_capacity_pairs : pair if pair.shape_name == "VM.Standard.E5.Flex"]
  e6_available_pairs   = [for pair in local.available_capacity_pairs : pair if pair.shape_name == "VM.Standard.E6.Flex"]
  e5_available_counts  = [for pair in local.e5_available_pairs : pair.available_count]
  e6_available_counts  = [for pair in local.e6_available_pairs : pair.available_count]
  e5_max_count         = length(local.e5_available_counts) > 0 ? max(local.e5_available_counts...) : 0
  e6_max_count         = length(local.e6_available_counts) > 0 ? max(local.e6_available_counts...) : 0
  e5_best_pairs        = [for pair in local.e5_available_pairs : pair if pair.available_count == local.e5_max_count]
  e6_best_pairs        = [for pair in local.e6_available_pairs : pair if pair.available_count == local.e6_max_count]
  selected_pair        = length(local.e5_best_pairs) > 0 ? local.e5_best_pairs[0] : local.e6_best_pairs[0]

  selected_shape = local.selected_pair.shape_name
  selected_ad    = local.selected_pair.availability_domain

  app_port  = local.selected_app == "openclaw" ? 18789 : 9119
  public_ip = data.oci_core_vnic.chat.public_ip_address
  base_url  = "http://${local.public_ip}:${local.app_port}"
  app_url   = local.selected_app == "openclaw" ? "${local.base_url}/#token=${random_string.openclaw_gateway_token.result}" : local.base_url
}

data "oci_identity_availability_domains" "ads" {
  compartment_id = var.tenancy_ocid
}

data "oci_core_shapes" "by_ad" {
  count               = length(data.oci_identity_availability_domains.ads.availability_domains)
  compartment_id      = var.compartment_id
  availability_domain = data.oci_identity_availability_domains.ads.availability_domains[count.index].name
}

data "oci_core_images" "oracle_linux" {
  compartment_id           = var.compartment_id
  operating_system         = "Oracle Linux"
  operating_system_version = "9"
  shape                    = local.selected_shape
  sort_by                  = "TIMECREATED"
  sort_order               = "DESC"
}

resource "oci_core_compute_capacity_report" "by_ad" {
  count               = length(local.ad_capacity_inputs)
  compartment_id      = var.tenancy_ocid
  availability_domain = local.ad_capacity_inputs[count.index].availability_domain

  dynamic "shape_availabilities" {
    for_each = local.ad_capacity_inputs[count.index].shapes

    content {
      instance_shape = shape_availabilities.value

      instance_shape_config {
        baseline_ocpu_utilization = "BASELINE_1_1"
        memory_in_gbs             = 16
        ocpus                     = 2
      }
    }
  }
}

resource "oci_identity_dynamic_group" "instance_principal" {
  count          = var.create_iam_policy ? 1 : 0
  compartment_id = var.tenancy_ocid
  name           = "chat_dg_${random_id.suffix.hex}"
  description    = "Compute instances in the target compartment can call OCI Generative AI with instance principal."
  matching_rule  = "instance.compartment.id = '${var.compartment_id}'"
}

resource "oci_identity_policy" "genai_chat" {
  count          = var.create_iam_policy ? 1 : 0
  compartment_id = var.tenancy_ocid
  name           = "chat_genai_${random_id.suffix.hex}"
  description    = "Allow the chat VM dynamic group to invoke OCI Generative AI chat models."

  statements = [
    "Allow dynamic-group ${oci_identity_dynamic_group.instance_principal[0].name} to use generative-ai-chat in compartment id ${var.compartment_id}",
    "Allow dynamic-group ${oci_identity_dynamic_group.instance_principal[0].name} to read generative-ai-model in compartment id ${var.compartment_id}"
  ]
}

resource "oci_core_vcn" "main" {
  compartment_id = var.compartment_id
  cidr_block     = "10.42.0.0/16"
  display_name   = "${local.name_prefix}-vcn"
  dns_label      = "chatvcn"
}

resource "oci_core_internet_gateway" "main" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.main.id
  enabled        = true
  display_name   = "${local.name_prefix}-igw"
}

resource "oci_core_route_table" "public" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.main.id
  display_name   = "${local.name_prefix}-public-rt"

  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.main.id
  }
}

resource "oci_core_security_list" "open" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.main.id
  display_name   = "${local.name_prefix}-open-sl"

  ingress_security_rules {
    protocol = "all"
    source   = "0.0.0.0/0"
  }

  egress_security_rules {
    protocol    = "all"
    destination = "0.0.0.0/0"
  }
}

resource "oci_core_subnet" "public" {
  compartment_id             = var.compartment_id
  vcn_id                     = oci_core_vcn.main.id
  cidr_block                 = "10.42.1.0/24"
  display_name               = "${local.name_prefix}-public-subnet"
  dns_label                  = "chatpub"
  prohibit_public_ip_on_vnic = false
  route_table_id             = oci_core_route_table.public.id
  security_list_ids          = [oci_core_security_list.open.id]
}

resource "oci_core_instance" "chat" {
  availability_domain = local.selected_ad
  compartment_id      = var.compartment_id
  display_name        = "${local.name_prefix}-${local.selected_app}"
  shape               = local.selected_shape

  shape_config {
    ocpus         = 2
    memory_in_gbs = 16
  }

  create_vnic_details {
    subnet_id        = oci_core_subnet.public.id
    assign_public_ip = true
    display_name     = "${local.name_prefix}-primary-vnic"
    hostname_label   = "chat-${random_id.suffix.hex}"
  }

  source_details {
    source_type             = "image"
    source_id               = data.oci_core_images.oracle_linux.images[0].id
    boot_volume_size_in_gbs = var.boot_volume_size_in_gbs
  }

  metadata = {
    ssh_authorized_keys = local.ssh_key
    user_data = base64encode(templatefile("${path.module}/cloud-init.yaml.tftpl", {
      bootstrap_content_gzip_b64 = base64gzip(templatefile("${path.module}/bootstrap.sh.tftpl", {
        app               = local.selected_app
        compartment_id    = var.compartment_id
        openclaw_gateway_token = random_string.openclaw_gateway_token.result
        system_prompt_b64 = base64encode(var.system_prompt)
      }))
    }))
  }

  depends_on = [
    oci_identity_policy.genai_chat
  ]
}

data "oci_core_vnic_attachments" "chat" {
  compartment_id = var.compartment_id
  instance_id    = oci_core_instance.chat.id
}

data "oci_core_vnic" "chat" {
  vnic_id = data.oci_core_vnic_attachments.chat.vnic_attachments[0].vnic_id
}

resource "null_resource" "wait_for_chat_ready" {
  triggers = {
    instance_id                 = oci_core_instance.chat.id
    app                         = local.selected_app
    app_port                    = tostring(local.app_port)
    public_ip                   = local.public_ip
    bootstrap_user_data_sha256  = sha256(oci_core_instance.chat.metadata["user_data"])
  }

  connection {
    type        = "ssh"
    host        = local.public_ip
    user        = "opc"
    private_key = tls_private_key.ssh.private_key_openssh
    timeout     = "15m"
    agent       = false
  }

  provisioner "remote-exec" {
    inline = [
      <<-EOT
      set -eu
      app="${local.selected_app}"
      port="${local.app_port}"
      token="${random_string.openclaw_gateway_token.result}"
      deadline=$(($(date +%s) + 900))
      echo "Waiting for $app bootstrap, cloud-init, local app URL, and provider smoke..."
      while [ "$(date +%s)" -lt "$deadline" ]; do
        if [ -s /home/opc/chat-bootstrap-error.txt ]; then
          echo "Bootstrap reported an error:"
          cat /home/opc/chat-bootstrap-error.txt || true
          echo "Bootstrap log tail:"
          sudo -n tail -n 160 /var/log/chat-bootstrap.log || true
          exit 1
        fi

        if [ -s /home/opc/chat-ready.txt ] && [ -s /home/opc/chat-provider-smoke.json ]; then
          if curl -fsS --max-time 10 "http://127.0.0.1:$port/" >/dev/null; then
            if [ "$app" = "openclaw" ]; then
              curl -fsS --max-time 10 -H "Authorization: Bearer $token" "http://127.0.0.1:$port/__openclaw/control-ui-config.json" >/dev/null
            fi
            grep -q "OK" /home/opc/chat-provider-smoke.json
            cloud-init status --wait >/tmp/chat-cloud-init-wait.log 2>&1
            echo "Chat app is ready:"
            cat /home/opc/chat-ready.txt
            exit 0
          fi
        fi

        if [ -f /home/opc/chat-bootstrap-progress.txt ]; then
          printf "Still waiting: "
          cat /home/opc/chat-bootstrap-progress.txt || true
        else
          echo "Still waiting: cloud-init has not written progress yet"
        fi
        sleep 10
      done

      echo "Timed out waiting for chat app readiness."
      echo "Progress:"
      cat /home/opc/chat-bootstrap-progress.txt 2>/dev/null || true
      echo "Bootstrap log tail:"
      sudo -n tail -n 160 /var/log/chat-bootstrap.log || true
      exit 1
      EOT
    ]
  }
}
