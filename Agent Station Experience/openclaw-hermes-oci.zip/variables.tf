variable "tenancy_ocid" {
  description = "Root tenancy OCID. Used only to create the dynamic group and IAM policy."
  type        = string
}

variable "compartment_id" {
  description = "Compartment OCID where the VM, VCN, and Generative AI access policy will be scoped."
  type        = string
}

variable "region" {
  description = "OCI region where the stack runs, for example sa-saopaulo-1. When using OCI CLI, set this to the profile region."
  type        = string
}

variable "app" {
  description = "Which chat app to install and expose: openclaw or hermes."
  type        = string
  default     = "hermes"

  validation {
    condition     = contains(["openclaw", "hermes"], lower(var.app))
    error_message = "app must be either openclaw or hermes."
  }
}

variable "create_iam_policy" {
  description = "Create the dynamic group and IAM policy needed for instance principal access to OCI Generative AI."
  type        = bool
  default     = true
}

variable "ssh_public_key" {
  description = "Optional SSH public key. Leave empty to let Terraform generate one and output the private key."
  type        = string
  default     = ""
}

variable "boot_volume_size_in_gbs" {
  description = "Boot volume size for the chat VM."
  type        = number
  default     = 80
}

variable "system_prompt" {
  description = "Default system prompt seeded into the selected app config/workspace."
  type        = string
  default     = "Voce e um assistente util rodando no OCI Generative AI. Responda no idioma da pessoa, de forma simples e direta. Para mensagens normais, cumprimentos ou perguntas gerais, responda naturalmente. Use ferramentas apenas quando a tarefa realmente precisar de uma acao externa."
}
