# OpenClaw Standalone on OCI via Terraform

Este projeto cria uma stack OCI em `us-chicago-1` com:

- VCN e subnet publica
- Internet Gateway
- route table
- security list com `22/tcp` e `18789/tcp`
- instância `VM.Standard.A1.Flex` com `4 OCPU / 16 GB`
- `cloud-init` que instala Node 22 binario
- `openclaw` standalone via npm, sem NemoClaw, sem sandbox e sem Docker
- `systemd` para manter o gateway ativo
- Telegram configurado com allowlist no `chat_id`
- `web_search` e `web_fetch` habilitados
- exec permissivo (`tools.exec.host=gateway`, `security=full`, `ask=off`)

## Entradas obrigatorias

O usuario preenche apenas:

- `compartment_id`
- `api_key`
- `telegram_bot_token`
- `telegram_chat_id`

Use:

```bash
cp terraform.tfvars.example terraform.tfvars
```

Depois:

```bash
terraform init
terraform apply
```

## O que mudou

Este stack foi otimizado para reduzir o tempo de `apply`:

- remove clone e build do NemoClaw
- remove Docker, OpenShell e onboarding interativo
- instala `openclaw` direto via npm
- grava a configuracao pronta em `~/.openclaw/openclaw.json`
- sobe o gateway com `systemd`
- faz smoke tests direto no endpoint, no gateway e no Telegram
- nao usa `local-exec` nem `external` provider para esperar bootstrap dentro do Resource Manager

## Modelo e catalogo

O modelo padrao configurado e `xai.grok-4-fast-non-reasoning`.

O catalogo inclui estes modelos OCI OpenAI-compatible para troca posterior dentro do OpenClaw:

- `xai.grok-4-fast-non-reasoning`
- `xai.grok-4-1-fast-non-reasoning`
- `xai.grok-4-1-fast-reasoning`
- `xai.grok-4.20-0309-non-reasoning`
- `xai.grok-4.20-0309-reasoning`
- `google.gemini-2.5-flash-lite`
- `google.gemini-2.5-flash`
- `google.gemini-2.5-pro`
- `openai.gpt-oss-20b`
- `openai.gpt-oss-120b`

## Outputs importantes

- `public_ip`
- `ssh_command`
- `ssh_private_key_pem`
- `dashboard_host`
- `dashboard_url_file`
- `dashboard_token_file`
- `bootstrap_status_file`
- `bootstrap_log_file`
- `cloud_init_output_file`
- `post_bootstrap_status_command`
- `post_dashboard_url_command`
- `post_bootstrap_log_command`
- `post_cloud_init_log_command`

## Arquivos uteis na VM

- `/var/log/openclaw-bootstrap.log`
- `/var/log/cloud-init-output.log`
- `/home/opc/openclaw-bootstrap-progress.txt`
- `/home/opc/openclaw-bootstrap-error.txt`
- `/home/opc/openclaw-bootstrap-status.txt`
- `/home/opc/openclaw-dashboard-url.txt`
- `/home/opc/openclaw-dashboard-token.txt`
- `/home/opc/openclaw-direct-smoke.json`
- `/home/opc/openclaw-gateway-health.json`
- `/home/opc/openclaw-model-smoke.json`
- `/home/opc/openclaw-telegram-smoke.json`

## Observacao de seguranca

Para permitir acesso direto pela URL publica da VM, este stack ativa um modo mais permissivo no Control UI:

- `gateway.bind = "lan"`
- `gateway.auth.mode = "token"`
- `gateway.controlUi.allowedOrigins` inclui o IP publico
- `gateway.controlUi.dangerouslyDisableDeviceAuth = true`

Isso foi feito para reproduzir o fluxo operacional que voce pediu: URL pronta com token e acesso imediato apos o `apply`.

## Comportamento do apply na OCI Stack

O `apply` nao espera o bootstrap da VM terminar. Isso e intencional para funcionar bem no OCI Resource Manager.

Fluxo esperado:

1. O `apply` cria rede e VM e finaliza.
2. O `cloud-init` continua executando dentro da VM.
3. Use os outputs `post_*_command` para consultar status e logs por SSH.
