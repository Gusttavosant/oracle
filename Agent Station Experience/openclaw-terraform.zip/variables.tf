variable "compartment_id" {
  description = "OCID do compartment onde a stack sera criada."
  type        = string
}

variable "api_key" {
  description = "API key do endpoint OpenAI-compatible da OCI."
  type        = string
  sensitive   = true
}

variable "telegram_bot_token" {
  description = "Token do bot Telegram."
  type        = string
  sensitive   = true
}

variable "telegram_chat_id" {
  description = "Chat ID autorizado para conversar com o bot no Telegram."
  type        = string
}
