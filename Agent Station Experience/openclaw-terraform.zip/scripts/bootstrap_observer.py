#!/usr/bin/env python3
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path


SSH_OPTIONS = [
    "-o",
    "StrictHostKeyChecking=no",
    "-o",
    "UserKnownHostsFile=/dev/null",
    "-o",
    "ServerAliveInterval=15",
    "-o",
    "ServerAliveCountMax=4",
    "-o",
    "ConnectTimeout=10",
]


def emit(msg: str) -> None:
    print(msg, flush=True)


def write_key(pem: str) -> str:
    tmp = tempfile.NamedTemporaryFile("w", delete=False)
    tmp.write(pem)
    tmp.flush()
    tmp.close()
    os.chmod(tmp.name, 0o600)
    return tmp.name


def run_ssh(host: str, key_path: str, command: str, timeout: int = 60) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["ssh", *SSH_OPTIONS, "-i", key_path, f"opc@{host}", command],
        text=True,
        capture_output=True,
        timeout=timeout,
    )


def emit_remote_snapshot(host: str, key_path: str, header: str) -> None:
    snapshot_cmd = r"""
set +e
echo "===== cloud-init status ====="
sudo cloud-init status --long 2>/dev/null || true
echo
echo "===== bootstrap progress ====="
cat /home/opc/openclaw-bootstrap-progress.txt 2>/dev/null || true
echo
echo "===== bootstrap error ====="
cat /home/opc/openclaw-bootstrap-error.txt 2>/dev/null || true
echo
echo "===== gateway service ====="
sudo systemctl status openclaw-gateway.service --no-pager 2>/dev/null || true
echo
echo "===== gateway journal ====="
sudo journalctl -u openclaw-gateway.service -n 120 --no-pager 2>/dev/null || true
echo
echo "===== bootstrap log tail ====="
sudo tail -n 120 /var/log/openclaw-bootstrap.log 2>/dev/null || true
echo
echo "===== cloud-init-output tail ====="
sudo tail -n 120 /var/log/cloud-init-output.log 2>/dev/null || true
"""
    snapshot = run_ssh(host, key_path, snapshot_cmd, timeout=180)
    text = ((snapshot.stdout or "") + (snapshot.stderr or "")).strip()
    if text:
        emit(header)
        emit(text)


def wait_mode() -> int:
    host = os.environ["TARGET_HOST"]
    pem = os.environ["SSH_PRIVATE_KEY"]
    timeout_seconds = int(os.environ.get("WAIT_TIMEOUT_SECONDS", "2700"))
    start = time.time()
    key_path = write_key(pem)
    last_progress = ""
    last_diag_elapsed = -1

    try:
        emit(f"[bootstrap-wait] waiting for SSH on {host}")
        while True:
            if time.time() - start > timeout_seconds:
                emit(f"[bootstrap-wait] timeout waiting for SSH after {timeout_seconds}s")
                return 1
            probe = run_ssh(host, key_path, "echo ssh-ready", timeout=20)
            if probe.returncode == 0 and "ssh-ready" in probe.stdout:
                emit("[bootstrap-wait] SSH reachable")
                break
            time.sleep(10)

        while True:
            elapsed = int(time.time() - start)
            if elapsed > timeout_seconds:
                emit(f"[bootstrap-wait] timeout waiting for bootstrap after {timeout_seconds}s")
                emit_remote_snapshot(host, key_path, "[bootstrap-wait] remote diagnostic snapshot:")
                return 1

            status_cmd = r"""
set -e
if [ -f /home/opc/.openclaw-bootstrap.done ]; then
  echo "__STATE__:done"
elif [ -f /home/opc/openclaw-bootstrap-error.txt ]; then
  echo "__STATE__:error"
else
  echo "__STATE__:running"
fi
if [ -f /home/opc/openclaw-bootstrap-progress.txt ]; then
  echo "__PROGRESS_BEGIN__"
  cat /home/opc/openclaw-bootstrap-progress.txt
  echo "__PROGRESS_END__"
fi
"""
            status = run_ssh(host, key_path, status_cmd, timeout=45)
            text = (status.stdout or "") + (status.stderr or "")
            state = "unknown"
            match = re.search(r"__STATE__:(\w+)", text)
            if match:
                state = match.group(1)
            progress_match = re.search(r"__PROGRESS_BEGIN__\n(.*?)\n__PROGRESS_END__", text, re.S)
            progress = progress_match.group(1).strip() if progress_match else ""

            if progress and progress != last_progress:
                emit(f"[bootstrap-wait] progress: {progress}")
                last_progress = progress
            else:
                emit(f"[bootstrap-wait] state={state} elapsed={elapsed}s")
                if elapsed >= 180 and elapsed - last_diag_elapsed >= 180:
                    emit_remote_snapshot(
                        host,
                        key_path,
                        f"[bootstrap-wait] diagnostic snapshot at {elapsed}s:",
                    )
                    last_diag_elapsed = elapsed

            if state == "done":
                emit("[bootstrap-wait] bootstrap completed successfully")
                return 0

            if state == "error":
                error = run_ssh(
                    host,
                    key_path,
                    "cat /home/opc/openclaw-bootstrap-error.txt 2>/dev/null || true",
                    timeout=30,
                )
                if error.stdout.strip():
                    emit(f"[bootstrap-wait] error: {error.stdout.strip()}")
                emit_remote_snapshot(host, key_path, "[bootstrap-wait] remote diagnostic snapshot:")
                return 1

            time.sleep(10)
    finally:
        try:
            Path(key_path).unlink(missing_ok=True)
        except Exception:
            pass


def fetch_mode() -> int:
    query = json.load(sys.stdin)
    host = query["host"]
    pem = query["private_key_pem"]
    key_path = write_key(pem)
    result = {
        "host": host,
        "bootstrap_state": "unreachable",
        "bootstrap_progress": "",
        "bootstrap_status": "",
        "bootstrap_error": "",
        "bootstrap_log_tail": "",
        "cloud_init_status": "",
        "cloud_init_output_tail": "",
        "dashboard_url": "",
        "dashboard_url_with_token": "",
        "dashboard_token": "",
        "gateway_health": "",
        "direct_smoke_result": "",
        "model_smoke_result": "",
        "telegram_smoke_result": "",
        "gateway_service_status": "",
        "dashboard_port_check": "",
    }

    try:
        probe = run_ssh(host, key_path, "echo ssh-ready", timeout=20)
        if probe.returncode != 0:
            print(json.dumps(result))
            return 0

        fetch_cmd = r"""
set +e
print_section() {
  local name="$1"
  local cmd="$2"
  echo "=====BEGIN:${name}====="
  bash -lc "$cmd" 2>/dev/null || true
  echo
  echo "=====END:${name}====="
}

if [ -f /home/opc/.openclaw-bootstrap.done ]; then
  echo "__BOOTSTRAP_STATE__:succeeded"
elif [ -f /home/opc/openclaw-bootstrap-error.txt ]; then
  echo "__BOOTSTRAP_STATE__:failed"
else
  echo "__BOOTSTRAP_STATE__:running"
fi

print_section progress 'cat /home/opc/openclaw-bootstrap-progress.txt'
print_section status 'cat /home/opc/openclaw-bootstrap-status.txt'
print_section error 'cat /home/opc/openclaw-bootstrap-error.txt'
print_section bootstrap_log 'sudo tail -n 200 /var/log/openclaw-bootstrap.log'
print_section cloud_init_status 'sudo cloud-init status --long'
print_section cloud_init_log 'sudo tail -n 200 /var/log/cloud-init-output.log'
print_section dashboard_url 'cat /home/opc/openclaw-dashboard-url.txt'
print_section dashboard_token 'cat /home/opc/openclaw-dashboard-token.txt'
print_section gateway_health 'cat /home/opc/openclaw-gateway-health.json'
print_section direct_smoke 'cat /home/opc/openclaw-direct-smoke.json'
print_section model_smoke 'cat /home/opc/openclaw-model-smoke.json'
print_section telegram_smoke 'cat /home/opc/openclaw-telegram-smoke.json'
print_section gateway_service 'sudo systemctl status openclaw-gateway.service --no-pager'
print_section port_18789 'sudo ss -ltnp | grep 18789'
"""
        fetched = run_ssh(host, key_path, fetch_cmd, timeout=180)
        text = fetched.stdout or ""

        state_match = re.search(r"__BOOTSTRAP_STATE__:(\w+)", text)
        if state_match:
            result["bootstrap_state"] = state_match.group(1)

        def section(name: str) -> str:
            match = re.search(
                rf"=====BEGIN:{re.escape(name)}=====\n(.*?)\n=====END:{re.escape(name)}=====",
                text,
                re.S,
            )
            return match.group(1).strip() if match else ""

        result["bootstrap_progress"] = section("progress")
        result["bootstrap_status"] = section("status")
        result["bootstrap_error"] = section("error")
        result["bootstrap_log_tail"] = section("bootstrap_log")
        result["cloud_init_status"] = section("cloud_init_status")
        result["cloud_init_output_tail"] = section("cloud_init_log")
        dashboard_url_section = section("dashboard_url")
        dashboard_url_lines = dashboard_url_section.splitlines()
        result["dashboard_url"] = dashboard_url_lines[1] if len(dashboard_url_lines) > 1 else dashboard_url_section
        if len(dashboard_url_lines) > 2:
            result["dashboard_url_with_token"] = dashboard_url_lines[2]
        result["dashboard_token"] = section("dashboard_token")
        result["gateway_health"] = section("gateway_health")
        result["direct_smoke_result"] = section("direct_smoke")
        result["model_smoke_result"] = section("model_smoke")
        result["telegram_smoke_result"] = section("telegram_smoke")
        result["gateway_service_status"] = section("gateway_service")
        result["dashboard_port_check"] = section("port_18789")
    finally:
        try:
            Path(key_path).unlink(missing_ok=True)
        except Exception:
            pass

    print(json.dumps(result))
    return 0


def main() -> int:
    if len(sys.argv) > 1 and sys.argv[1] == "wait":
        return wait_mode()
    return fetch_mode()


if __name__ == "__main__":
    raise SystemExit(main())
