provider "oci" {
  region = local.region
}

locals {
  region                  = "us-chicago-1"
  instance_display_name   = "openclaw-standalone"
  shape                   = "VM.Standard.A1.Flex"
  shape_ocpus             = 4
  shape_memory_in_gbs     = 16
  boot_volume_size_gbs    = 50
  vcn_cidr                = "10.42.0.0/16"
  subnet_cidr             = "10.42.0.0/24"
  base_url                = "https://inference.generativeai.us-chicago-1.oci.oraclecloud.com/openai/v1"
  default_model           = "xai.grok-4-fast-non-reasoning"
  openclaw_version        = "2026.4.27"
  node_version            = "22.22.2"
  supported_models = [
    "xai.grok-4-fast-non-reasoning",
    "xai.grok-4-1-fast-non-reasoning",
    "xai.grok-4-1-fast-reasoning",
    "xai.grok-4.20-0309-non-reasoning",
    "xai.grok-4.20-0309-reasoning",
    "google.gemini-2.5-flash-lite",
    "google.gemini-2.5-flash",
    "google.gemini-2.5-pro",
    "openai.gpt-oss-20b",
    "openai.gpt-oss-120b",
  ]

  supported_model_catalog = [
    for model in local.supported_models : {
      id    = model
      name  = model
      api   = "openai-completions"
      input = ["text"]
    }
  ]

  bootstrap_script = templatefile("${path.module}/bootstrap.sh.tftpl", {
    api_key                      = var.api_key
    telegram_bot_token           = var.telegram_bot_token
    telegram_chat_id             = var.telegram_chat_id
    base_url                     = local.base_url
    region                       = local.region
    default_model                = local.default_model
    node_version                 = local.node_version
    openclaw_version             = local.openclaw_version
    supported_model_catalog_json = jsonencode(local.supported_model_catalog)
  })

  cloud_init = templatefile("${path.module}/cloud-init.yaml.tftpl", {
    bootstrap_script = local.bootstrap_script
  })
}

resource "tls_private_key" "ssh" {
  algorithm = "RSA"
  rsa_bits  = 4096
}

data "oci_identity_availability_domains" "ads" {
  compartment_id = var.compartment_id
}

data "oci_core_images" "oracle_linux_9" {
  compartment_id           = var.compartment_id
  operating_system         = "Oracle Linux"
  operating_system_version = "9"
  shape                    = local.shape
  sort_by                  = "TIMECREATED"
  sort_order               = "DESC"
  state                    = "AVAILABLE"
}

resource "oci_core_vcn" "this" {
  compartment_id = var.compartment_id
  cidr_block     = local.vcn_cidr
  display_name   = "${local.instance_display_name}-vcn"
  dns_label      = "openclawvcn"
}

resource "oci_core_internet_gateway" "this" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.this.id
  display_name   = "${local.instance_display_name}-igw"
  enabled        = true
}

resource "oci_core_route_table" "public" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.this.id
  display_name   = "${local.instance_display_name}-public-rt"

  route_rules {
    network_entity_id = oci_core_internet_gateway.this.id
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
  }
}

resource "oci_core_security_list" "public" {
  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.this.id
  display_name   = "${local.instance_display_name}-public-sl"

  egress_security_rules {
    protocol         = "all"
    destination      = "0.0.0.0/0"
    destination_type = "CIDR_BLOCK"
  }

  ingress_security_rules {
    protocol    = "6"
    source      = "0.0.0.0/0"
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 22
      max = 22
    }
  }

  ingress_security_rules {
    protocol    = "6"
    source      = "0.0.0.0/0"
    source_type = "CIDR_BLOCK"

    tcp_options {
      min = 18789
      max = 18789
    }
  }
}

resource "oci_core_subnet" "public" {
  compartment_id             = var.compartment_id
  vcn_id                     = oci_core_vcn.this.id
  cidr_block                 = local.subnet_cidr
  display_name               = "${local.instance_display_name}-public-subnet"
  dns_label                  = "publicsubnet"
  route_table_id             = oci_core_route_table.public.id
  security_list_ids          = [oci_core_security_list.public.id]
  prohibit_public_ip_on_vnic = false
}

resource "oci_core_instance" "this" {
  availability_domain = data.oci_identity_availability_domains.ads.availability_domains[0].name
  compartment_id      = var.compartment_id
  shape               = local.shape
  display_name        = local.instance_display_name

  shape_config {
    ocpus         = local.shape_ocpus
    memory_in_gbs = local.shape_memory_in_gbs
  }

  create_vnic_details {
    subnet_id        = oci_core_subnet.public.id
    assign_public_ip = true
    display_name     = "${local.instance_display_name}-vnic"
    hostname_label   = "openclaw"
  }

  source_details {
    source_type             = "image"
    source_id               = data.oci_core_images.oracle_linux_9.images[0].id
    boot_volume_size_in_gbs = local.boot_volume_size_gbs
  }

  metadata = {
    ssh_authorized_keys = tls_private_key.ssh.public_key_openssh
    user_data           = base64encode(local.cloud_init)
  }
}

data "oci_core_vnic_attachments" "this" {
  compartment_id = var.compartment_id
  instance_id    = oci_core_instance.this.id
}

data "oci_core_vnic" "primary" {
  vnic_id = data.oci_core_vnic_attachments.this.vnic_attachments[0].vnic_id
}
