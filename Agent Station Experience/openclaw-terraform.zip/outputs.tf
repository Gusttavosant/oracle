output "region" {
  value = local.region
}

output "public_ip" {
  value = data.oci_core_vnic.primary.public_ip_address
}

output "instance_id" {
  value = oci_core_instance.this.id
}

output "default_model" {
  value = local.default_model
}

output "supported_models" {
  value = local.supported_models
}

output "ssh_public_key_openssh" {
  value = tls_private_key.ssh.public_key_openssh
}

output "ssh_private_key_pem" {
  value     = tls_private_key.ssh.private_key_pem
  sensitive = true
}

output "ssh_command" {
  value = "ssh -i ./generated_ssh_key.pem opc@${data.oci_core_vnic.primary.public_ip_address}"
}

output "dashboard_host" {
  value = "http://${data.oci_core_vnic.primary.public_ip_address}:18789"
}

output "dashboard_url_file" {
  value = "/home/opc/openclaw-dashboard-url.txt"
}

output "dashboard_token_file" {
  value = "/home/opc/openclaw-dashboard-token.txt"
}

output "bootstrap_status_file" {
  value = "/home/opc/openclaw-bootstrap-status.txt"
}

output "bootstrap_log_file" {
  value = "/var/log/openclaw-bootstrap.log"
}

output "cloud_init_output_file" {
  value = "/var/log/cloud-init-output.log"
}

output "bootstrap_progress_file" {
  value = "/home/opc/openclaw-bootstrap-progress.txt"
}

output "direct_smoke_file" {
  value = "/home/opc/openclaw-direct-smoke.json"
}

output "gateway_health_file" {
  value = "/home/opc/openclaw-gateway-health.json"
}

output "model_smoke_file" {
  value = "/home/opc/openclaw-model-smoke.json"
}

output "telegram_smoke_file" {
  value = "/home/opc/openclaw-telegram-smoke.json"
}

output "postchecks_log_file" {
  value = "/var/log/openclaw-postchecks.log"
}

output "bootstrap_error_file" {
  value = "/home/opc/openclaw-bootstrap-error.txt"
}

output "post_bootstrap_status_command" {
  value = "ssh -i ./generated_ssh_key.pem opc@${data.oci_core_vnic.primary.public_ip_address} 'cat /home/opc/openclaw-bootstrap-status.txt'"
}

output "post_dashboard_url_command" {
  value = "ssh -i ./generated_ssh_key.pem opc@${data.oci_core_vnic.primary.public_ip_address} 'cat /home/opc/openclaw-dashboard-url.txt'"
}

output "post_bootstrap_log_command" {
  value = "ssh -i ./generated_ssh_key.pem opc@${data.oci_core_vnic.primary.public_ip_address} 'sudo tail -n 200 /var/log/openclaw-bootstrap.log'"
}

output "post_cloud_init_log_command" {
  value = "ssh -i ./generated_ssh_key.pem opc@${data.oci_core_vnic.primary.public_ip_address} 'sudo tail -n 200 /var/log/cloud-init-output.log'"
}
