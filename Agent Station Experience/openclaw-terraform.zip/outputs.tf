output "public_ip" {
  value = data.oci_core_vnic.primary.public_ip_address
}

output "dashboard_host" {
  value = "http://${data.oci_core_vnic.primary.public_ip_address}:18789"
}

output "dashboard_url" {
  value = "http://${data.oci_core_vnic.primary.public_ip_address}:18789"
}

output "dashboard_token" {
  value = local.dashboard_token
}

output "dashboard_url_with_token" {
  value = "http://${data.oci_core_vnic.primary.public_ip_address}:18789/#token=${local.dashboard_token}"
}

output "ssh_private_key_pem" {
  value = nonsensitive(tls_private_key.ssh.private_key_pem)
}

output "ssh_command" {
  value = "ssh -i ./generated_ssh_key.pem opc@${data.oci_core_vnic.primary.public_ip_address}"
}
