variable "compartment_id" {
  description = "OCID do compartment onde a stack sera criada."
  type        = string
}

variable "api_key" {
  description = "API key do endpoint OpenAI-compatible da OCI."
  type        = string
  sensitive   = true
}

variable "telegram_bot_token" {
  description = "Token do bot Telegram."
  type        = string
  sensitive   = true
}

variable "telegram_chat_id" {
  description = "Chat ID autorizado para conversar com o bot no Telegram."
  type        = string
}

variable "region" {
  description = "Regiao OCI usada pelo stack."
  type        = string
  default     = "us-chicago-1"

  validation {
    condition     = contains(["us-chicago-1", "sa-saopaulo-1"], var.region)
    error_message = "region deve ser us-chicago-1 ou sa-saopaulo-1."
  }
}

variable "model" {
  description = "Modelo padrao usado pelo OpenClaw."
  type        = string
  default     = "xai.grok-4-fast-non-reasoning"

  validation {
    condition = contains([
      "xai.grok-4-fast-non-reasoning",
      "xai.grok-4-fast-reasoning",
      "xai.grok-4-1-fast-reasoning",
      "xai.grok-4-1-fast-non-reasoning",
      "google.gemini-2.5-flash-lite",
      "google.gemini-2.5-flash",
      "xai.grok-4.3",
      "openai.gpt-oss-20b",
      "openai.gpt-oss-120b",
      "meta.llama-3.3-70b-instruct",
    ], var.model)
    error_message = "model precisa ser um dos modelos suportados pelo stack."
  }
}

variable "create_generative_ai_policy" {
  description = "Quando true, cria a policy de Generative AI. Use apenas na home region; fora dela, crie manualmente em Identity > Policies: https://docs.oracle.com/en-us/iaas/Content/generative-ai/add-api-permission.htm"
  type        = bool
  default     = true
}
