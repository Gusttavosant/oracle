async function api(path) {
  const res = await fetch(path);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

async function apiPost(path, payload = {}) {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

let toastStack = null;

function getToastStack() {
  if (toastStack) return toastStack;
  toastStack = document.createElement("div");
  toastStack.className = "toast-stack";
  document.body.appendChild(toastStack);
  return toastStack;
}

function showErrorPopup(message) {
  const stack = getToastStack();
  const toast = document.createElement("div");
  toast.className = "toast error";
  toast.innerHTML = `<span class="toast-title">Erro</span>${String(message || "Falha inesperada.")}`;
  stack.appendChild(toast);
  setTimeout(() => {
    toast.remove();
    if (!stack.children.length) {
      stack.remove();
      toastStack = null;
    }
  }, 5200);
}

function qs(id) {
  return document.getElementById(id);
}

function renderConversationList(items) {
  const wrap = qs("convList");
  wrap.innerHTML = "";

  for (const c of items) {
    const row = document.createElement("div");
    row.className = "conversation-item";
    row.innerHTML = `<div>${c.title || "Sem t�tulo"}</div><small>${c.id}</small><small>docs=${c.docs} | chunks=${c.chunks}</small>`;
    row.onclick = () => {
      qs("convInput").value = c.id;
      loadChunks();
    };
    wrap.appendChild(row);
  }
}

function chunkCard(item) {
  const card = document.createElement("article");
  card.className = "chunk-card glass";

  const scoreText = item.score === null || item.score === undefined ? "-" : Number(item.score).toFixed(4);

  const vectorFull = item.vector ? JSON.stringify(item.vector) : null;
  const vectorHead = Array.isArray(item.vector_head) ? item.vector_head.join(", ") : "";

  const vectorHtml = vectorFull
    ? `<details class="tool-details"><summary>Vetor completo (${item.vector_dim})</summary><pre>${vectorFull}</pre></details>`
    : `<div class="chunk-meta">vector_dim=${item.vector_dim} | vector_head=[${vectorHead}]</div>`;

  card.innerHTML = `
    <div class="chunk-head">
      <strong>${item.filename}</strong>
      <span>chunk #${item.chunk_index}</span>
    </div>
    <div class="chunk-meta">score=${scoreText} | conversation=${item.conversation_id}</div>
    <pre class="chunk-text">${item.text}</pre>
    ${vectorHtml}
  `;

  return card;
}

function renderChunks(payload) {
  qs("meta").textContent = `total=${payload.total_chunks} | retornados=${payload.returned} | modo_query=${payload.query_mode}`;

  const wrap = qs("chunkResults");
  wrap.innerHTML = "";
  for (const item of payload.items) {
    wrap.appendChild(chunkCard(item));
  }
}

async function loadChunks() {
  const convId = qs("convInput").value.trim();
  const query = qs("queryInput").value.trim();
  const top = qs("topInput").value;
  const limit = qs("limitInput").value;
  const includeVectors = qs("includeVectors").checked;

  const params = new URLSearchParams();
  if (convId) params.set("conversation_id", convId);
  if (query) params.set("q", query);
  params.set("top", String(top || 20));
  params.set("limit", String(limit || 50));
  if (includeVectors) params.set("include_vectors", "1");

  qs("meta").textContent = "Carregando chunks...";
  try {
    const payload = await api(`/api/debug/chunks?${params.toString()}`);
    renderChunks(payload);
  } catch (err) {
    qs("meta").textContent = `Erro: ${err.message || err}`;
    showErrorPopup(`Erro ao carregar chunks: ${err.message || err}`);
  }
}

async function init() {
  qs("loadBtn").onclick = loadChunks;
  qs("clearVectorsBtn").onclick = async () => {
    const ok = confirm("Limpar toda a base vetorial (documents + chunks)?");
    if (!ok) return;
    qs("meta").textContent = "Limpando base vetorial...";
    try {
      const out = await apiPost("/api/debug/clear-vectors");
      qs("meta").textContent = `Base vetorial limpa. Removidos docs=${out.cleared.documents}, chunks=${out.cleared.chunks}.`;
      const convs = await api("/api/debug/conversations");
      renderConversationList(convs);
      await loadChunks();
    } catch (err) {
      qs("meta").textContent = `Erro ao limpar: ${err.message || err}`;
      showErrorPopup(`Erro ao limpar base vetorial: ${err.message || err}`);
    }
  };

  try {
    const convs = await api("/api/debug/conversations");
    renderConversationList(convs);
  } catch (_) {
    // ignore sidebar errors
  }

  await loadChunks();
}

init();
