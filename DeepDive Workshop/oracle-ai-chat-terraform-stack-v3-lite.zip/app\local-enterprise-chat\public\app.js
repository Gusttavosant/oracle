let currentConversationId = null;
let toastStack = null;

function getToastStack() {
  if (toastStack) return toastStack;
  toastStack = document.createElement("div");
  toastStack.className = "toast-stack";
  document.body.appendChild(toastStack);
  return toastStack;
}

function showErrorPopup(message) {
  const stack = getToastStack();
  const toast = document.createElement("div");
  toast.className = "toast error";
  toast.innerHTML = `<span class="toast-title">Erro</span>${String(message || "Falha inesperada.")}`;
  stack.appendChild(toast);
  setTimeout(() => {
    toast.remove();
    if (!stack.children.length) {
      stack.remove();
      toastStack = null;
    }
  }, 5200);
}
async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function setStatus(text) {
  document.getElementById("uploadStatus").textContent = text;
}

function readFileAsBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || "");
      const base64 = dataUrl.includes(",") ? dataUrl.split(",")[1] : "";
      resolve(base64);
    };
    reader.onerror = () => reject(new Error(`Falha lendo arquivo ${file.name}`));
    reader.readAsDataURL(file);
  });
}

function buildToolDetails(metadata) {
  const trace = metadata?.tool_trace;
  if (!Array.isArray(trace) || !trace.length) return null;

  const details = document.createElement("details");
  details.className = "tool-details";

  const summary = document.createElement("summary");
  summary.textContent = "Tools usadas";
  details.appendChild(summary);

  for (const toolEntry of trace) {
    const block = document.createElement("div");
    block.className = "tool-item";

    const title = document.createElement("div");
    title.className = "tool-name";
    title.textContent = `Tool: ${toolEntry.tool || "desconhecida"}`;
    block.appendChild(title);

    if (toolEntry.query) {
      const query = document.createElement("div");
      query.className = "tool-query";
      query.textContent = `Query: ${toolEntry.query}`;
      block.appendChild(query);
    }

    const items = Array.isArray(toolEntry.items) ? toolEntry.items : [];
    if (items.length) {
      const list = document.createElement("ul");
      list.className = "tool-list";
      for (const item of items) {
        const li = document.createElement("li");
        const titleText = item.title ? `${item.title}` : "Item";
        const urlText = item.url ? ` (${item.url})` : "";
        const descText = item.text ? ` - ${item.text}` : "";
        li.textContent = `${titleText}${urlText}${descText}`;
        list.appendChild(li);
      }
      block.appendChild(list);
    }

    details.appendChild(block);
  }

  return details;
}

function createMessageElement(message, pending = false) {
  const card = document.createElement("div");
  card.className = `msg ${message.role}`;
  if (pending) card.classList.add("pending");

  const role = document.createElement("div");
  role.className = "msg-role";
  role.textContent = message.role === "assistant" ? "ASSISTANT" : "USER";

  const body = document.createElement("div");
  body.className = "msg-content";
  body.textContent = message.content || "";

  card.appendChild(role);
  card.appendChild(body);

  if (message.role === "assistant") {
    const details = buildToolDetails(message.metadata || {});
    if (details) card.appendChild(details);
  }

  return card;
}

function renderMessages(messages) {
  const wrap = document.getElementById("messages");
  wrap.innerHTML = "";
  for (const m of messages) {
    wrap.appendChild(createMessageElement(m));
  }
  wrap.scrollTop = wrap.scrollHeight;
}

function appendMessage(message, pending = false) {
  const wrap = document.getElementById("messages");
  const el = createMessageElement(message, pending);
  wrap.appendChild(el);
  wrap.scrollTop = wrap.scrollHeight;
  return el;
}

function updatePendingAssistant(el, content, metadata) {
  el.classList.remove("pending");
  const body = el.querySelector(".msg-content");
  if (body) body.textContent = content;

  const oldDetails = el.querySelector("details.tool-details");
  if (oldDetails) oldDetails.remove();

  const details = buildToolDetails(metadata || {});
  if (details) el.appendChild(details);
}

function updatePendingAssistantText(el, content) {
  const body = el.querySelector(".msg-content");
  if (body) body.textContent = content;
}

async function streamChat(payload, onDelta) {
  const res = await fetch("/api/chat/stream", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok || !res.body) {
    const txt = await res.text().catch(() => "");
    throw new Error(txt || `HTTP ${res.status}`);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let assistantText = "";
  let donePayload = null;

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const chunks = buffer.split("\n\n");
    buffer = chunks.pop() || "";

    for (const chunk of chunks) {
      const lines = chunk.split(/\r?\n/).filter(Boolean);
      let event = "message";
      let dataRaw = "";

      for (const line of lines) {
        if (line.startsWith("event:")) event = line.slice(6).trim();
        if (line.startsWith("data:")) dataRaw += line.slice(5).trim();
      }

      if (!dataRaw) continue;
      let data = {};
      try {
        data = JSON.parse(dataRaw);
      } catch {
        data = {};
      }

      if (event === "delta") {
        const piece = String(data.text || "");
        if (piece) {
          assistantText += piece;
          onDelta(assistantText);
        }
      } else if (event === "done") {
        donePayload = data;
      } else if (event === "error") {
        throw new Error(String(data.error || "stream error"));
      }
    }
  }

  return {
    assistant_message: donePayload?.assistant_message || assistantText,
    metadata: donePayload?.metadata || {},
  };
}

async function loadConversations() {
  const items = await api("/api/conversations");
  const list = document.getElementById("conversationList");
  list.innerHTML = "";

  for (const c of items) {
    const row = document.createElement("div");
    row.className = "conversation-item";
    if (c.id === currentConversationId) row.classList.add("active");
    row.innerHTML = `<div>${c.title || "Nova conversa"}</div><small>${c.id}</small>`;
    row.onclick = async () => {
      currentConversationId = c.id;
      document.getElementById("activeConversation").textContent = c.id;
      await refreshCurrentConversation();
      loadConversations();
    };
    list.appendChild(row);
  }
}

async function loadDocuments() {
  const wrap = document.getElementById("docList");
  wrap.innerHTML = "";
  if (!currentConversationId) return;

  const docs = await api(`/api/conversations/${encodeURIComponent(currentConversationId)}/documents`);
  if (!docs.length) {
    wrap.innerHTML = `<div class="doc-item">Sem documentos neste chat.</div>`;
    return;
  }

  for (const doc of docs) {
    const item = document.createElement("div");
    item.className = "doc-item";
    item.innerHTML = `<strong>${doc.filename}</strong><small>${doc.chunk_count} chunks</small>`;
    wrap.appendChild(item);
  }
}

async function refreshCurrentConversation() {
  if (!currentConversationId) return;
  const msgs = await api(`/api/conversations/${encodeURIComponent(currentConversationId)}/messages`);
  renderMessages(msgs);
  await loadDocuments();
}

async function createConversation() {
  const data = await api("/api/conversations/new", {
    method: "POST",
    body: JSON.stringify({ title: "Nova conversa" }),
  });
  currentConversationId = data.conversation_id;
  document.getElementById("activeConversation").textContent = currentConversationId;
  renderMessages([]);
  await loadConversations();
  await loadDocuments();
  setStatus("Conversa criada com sucesso.");
}

async function uploadFiles() {
  if (!currentConversationId) {
    showErrorPopup("Crie um chat antes de enviar arquivos.");
    return;
  }

  const input = document.getElementById("fileInput");
  const files = Array.from(input.files || []);
  if (!files.length) {
    showErrorPopup("Selecione pelo menos um arquivo.");
    return;
  }

  let sent = 0;
  for (const file of files) {
    setStatus(`Lendo ${file.name}...`);
    const contentBase64 = await readFileAsBase64(file);
    setStatus(`Processando ${file.name}...`);
    await api("/api/files/upload", {
      method: "POST",
      body: JSON.stringify({
        conversation_id: currentConversationId,
        filename: file.name,
        mime_type: file.type || "application/octet-stream",
        content_base64: contentBase64,
      }),
    });
    sent += 1;
  }

  input.value = "";
  setStatus(`${sent} arquivo(s) enviado(s) com sucesso.`);
  await loadDocuments();
}

document.getElementById("newChatBtn").onclick = createConversation;
document.getElementById("uploadBtn").onclick = async () => {
  try {
    await uploadFiles();
  } catch (err) {
    setStatus(`Erro no upload: ${err.message || err}`);
    showErrorPopup(`Erro no upload: ${err.message || err}`);
  }
};

document.getElementById("chatForm").onsubmit = async (e) => {
  e.preventDefault();
  if (!currentConversationId) {
    showErrorPopup("Crie ou selecione uma conversa primeiro.");
    return;
  }

  const input = document.getElementById("messageInput");
  const text = input.value.trim();
  if (!text) return;
  input.value = "";

  const knowledgeEnabled = document.getElementById("knowledgeToggle").checked;
  const webSearchEnabled = document.getElementById("webSearchToggle").checked;

  appendMessage({ role: "user", content: text, metadata: {} });
  const pendingAssistant = appendMessage({ role: "assistant", content: "Gerando resposta...", metadata: {} }, true);

  try {
    const result = await streamChat(
      {
        conversation_id: currentConversationId,
        message: text,
        use_knowledge: knowledgeEnabled,
        use_web_search: webSearchEnabled,
      },
      (partialText) => updatePendingAssistantText(pendingAssistant, partialText)
    );

    updatePendingAssistant(pendingAssistant, result.assistant_message, result.metadata || {});
    await loadConversations();
  } catch (err) {
    updatePendingAssistant(pendingAssistant, `Erro ao gerar resposta: ${err.message || err}`, {});
    showErrorPopup(`Erro ao gerar resposta: ${err.message || err}`);
  }
};

window.onload = async () => {
  try {
    const health = await api("/api/health");
    const chunkInfo = health.chunk_chars
      ? `${health.chunk_chars} caracteres`
      : `${health.chunk_lines} linhas`;
    setStatus(`Pronto. Regiao=${health.region} | Chunking=${chunkInfo}`);
    await loadConversations();
  } catch (err) {
    setStatus(`Falha ao inicializar UI: ${err.message || err}`);
    showErrorPopup(`Falha ao inicializar UI: ${err.message || err}`);
  }
};
