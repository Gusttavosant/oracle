locals {
  resolved_tenancy_ocid    = trimspace(var.tenancy_ocid)
  resolved_compartment_ocid = trimspace(var.compartment_ocid) != "" ? trimspace(var.compartment_ocid) : trimspace(var.tenancy_ocid)

  app_name                 = "oracle-ai-chat"
  app_port                 = 8080
  vcn_cidr                 = "10.42.0.0/16"
  subnet_cidr              = "10.42.1.0/24"
  instance_shape           = "VM.Standard.E5.Flex"
  instance_ocpus           = 2
  instance_memory_gb       = 16
  instance_display_name    = "oracle-ai-chat-vm"

  generated_ssh_public_key = trimspace(var.ssh_public_key) == "" ? tls_private_key.ssh_access[0].public_key_openssh : null
  ssh_authorized_keys      = trimspace(var.ssh_public_key) != "" ? trimspace(var.ssh_public_key) : local.generated_ssh_public_key

  short_term_project_id = random_uuid.short_term_project.result
  long_term_project_id  = random_uuid.long_term_project.result
}

check "required_ocids" {
  assert {
    condition     = local.resolved_tenancy_ocid != "" && local.resolved_compartment_ocid != ""
    error_message = "Configure tenancy_ocid (e opcionalmente compartment_ocid)."
  }
}

data "oci_identity_availability_domains" "ads" {
  compartment_id = local.resolved_tenancy_ocid
}

data "oci_core_images" "oracle_linux" {
  compartment_id           = local.resolved_compartment_ocid
  operating_system         = "Oracle Linux"
  operating_system_version = "8"
  shape                    = local.instance_shape
  sort_by                  = "TIMECREATED"
  sort_order               = "DESC"
}

data "oci_objectstorage_namespace" "ns" {
  compartment_id = local.resolved_tenancy_ocid
}

data "archive_file" "app_zip" {
  type        = "zip"
  source_dir  = "${path.module}/app/local-enterprise-chat"
  output_path = "${path.module}/local-enterprise-chat.zip"
  excludes = [
    "node_modules",
    "data",
    "wallet",
    ".env",
    "*.log"
  ]
}

resource "random_pet" "suffix" {
  length    = 2
  separator = "-"
}

resource "random_uuid" "short_term_project" {}
resource "random_uuid" "long_term_project" {}

resource "time_static" "deployment_time" {}

resource "tls_private_key" "iam_api_key" {
  algorithm = "RSA"
  rsa_bits  = 2048
}

resource "tls_private_key" "ssh_access" {
  count     = trimspace(var.ssh_public_key) == "" ? 1 : 0
  algorithm = "RSA"
  rsa_bits  = 4096
}

resource "oci_identity_group" "app_group" {
  compartment_id = local.resolved_tenancy_ocid
  name           = "oracle-ai-chat-group-${random_pet.suffix.id}"
  description    = "Group for Oracle AI chat app IAM API key access"
}

resource "oci_identity_user" "app_user" {
  compartment_id = local.resolved_tenancy_ocid
  name           = "oracle-ai-chat-user-${random_pet.suffix.id}"
  email          = "oracle-ai-chat-${random_pet.suffix.id}@example.com"
  description    = "User used by Oracle AI chat app"
}

resource "oci_identity_user_group_membership" "app_membership" {
  group_id = oci_identity_group.app_group.id
  user_id  = oci_identity_user.app_user.id
}

resource "oci_identity_api_key" "app_user_key" {
  user_id   = oci_identity_user.app_user.id
  key_value = tls_private_key.iam_api_key.public_key_pem
}

resource "oci_identity_policy" "genai_policy" {
  compartment_id = local.resolved_tenancy_ocid
  name           = "oracle-ai-chat-policy-${random_pet.suffix.id}"
  description    = "Policy to allow Oracle AI chat app user group to call Generative AI"
  statements = [
    "Allow group ${oci_identity_group.app_group.name} to use generative-ai-family in compartment id ${local.resolved_compartment_ocid}",
    "Allow group ${oci_identity_group.app_group.name} to read objectstorage-namespaces in tenancy",
    "Allow group ${oci_identity_group.app_group.name} to read buckets in compartment id ${local.resolved_compartment_ocid}",
    "Allow group ${oci_identity_group.app_group.name} to read objects in compartment id ${local.resolved_compartment_ocid}"
  ]
}

resource "oci_core_vcn" "app_vcn" {
  compartment_id = local.resolved_compartment_ocid
  cidr_blocks    = [local.vcn_cidr]
  display_name   = "oracle-ai-chat-vcn-${random_pet.suffix.id}"
  dns_label      = "oaichatvcn"
}

resource "oci_core_internet_gateway" "app_igw" {
  compartment_id = local.resolved_compartment_ocid
  vcn_id         = oci_core_vcn.app_vcn.id
  display_name   = "oracle-ai-chat-igw-${random_pet.suffix.id}"
  enabled        = true
}

resource "oci_core_route_table" "app_rt" {
  compartment_id = local.resolved_compartment_ocid
  vcn_id         = oci_core_vcn.app_vcn.id
  display_name   = "oracle-ai-chat-rt-${random_pet.suffix.id}"

  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.app_igw.id
  }
}

resource "oci_core_security_list" "app_sl" {
  compartment_id = local.resolved_compartment_ocid
  vcn_id         = oci_core_vcn.app_vcn.id
  display_name   = "oracle-ai-chat-open-sl-${random_pet.suffix.id}"

  ingress_security_rules {
    source   = "0.0.0.0/0"
    protocol = "all"
  }

  egress_security_rules {
    destination = "0.0.0.0/0"
    protocol    = "all"
  }
}

resource "oci_core_subnet" "app_subnet" {
  compartment_id      = local.resolved_compartment_ocid
  vcn_id              = oci_core_vcn.app_vcn.id
  cidr_block          = local.subnet_cidr
  display_name        = "oracle-ai-chat-subnet-${random_pet.suffix.id}"
  dns_label           = "appsubnet"
  route_table_id      = oci_core_route_table.app_rt.id
  security_list_ids   = [oci_core_security_list.app_sl.id]
  prohibit_public_ip_on_vnic = false
}

resource "oci_objectstorage_bucket" "app_bucket" {
  compartment_id      = local.resolved_compartment_ocid
  namespace           = data.oci_objectstorage_namespace.ns.namespace
  name                = "oracle-ai-chat-artifacts-${random_pet.suffix.id}"
  access_type         = "NoPublicAccess"
  auto_tiering        = "InfrequentAccess"
  versioning          = "Disabled"
}

resource "oci_objectstorage_object" "app_archive" {
  bucket    = oci_objectstorage_bucket.app_bucket.name
  namespace = data.oci_objectstorage_namespace.ns.namespace
  object    = "local-enterprise-chat-${random_pet.suffix.id}.zip"
  source    = data.archive_file.app_zip.output_path
  content_type = "application/zip"
}

resource "oci_objectstorage_preauthrequest" "app_archive_download" {
  bucket       = oci_objectstorage_bucket.app_bucket.name
  namespace    = data.oci_objectstorage_namespace.ns.namespace
  name         = "oracle-ai-chat-archive-par-${random_pet.suffix.id}"
  access_type  = "ObjectRead"
  object_name  = oci_objectstorage_object.app_archive.object
  time_expires = timeadd(time_static.deployment_time.rfc3339, "720h")
}

resource "oci_core_instance" "app_vm" {
  compartment_id      = local.resolved_compartment_ocid
  availability_domain = data.oci_identity_availability_domains.ads.availability_domains[0].name
  display_name        = local.instance_display_name
  shape               = local.instance_shape

  shape_config {
    ocpus         = local.instance_ocpus
    memory_in_gbs = local.instance_memory_gb
  }

  source_details {
    source_type = "image"
    source_id   = data.oci_core_images.oracle_linux.images[0].id
  }

  create_vnic_details {
    subnet_id        = oci_core_subnet.app_subnet.id
    assign_public_ip = true
    display_name     = "oracle-ai-chat-vnic"
    hostname_label   = "oaichat"
  }

  metadata = {
    ssh_authorized_keys = local.ssh_authorized_keys
    user_data = base64encode(templatefile("${path.module}/cloud-init.sh.tftpl", {
      app_download_url   = "https://objectstorage.${var.region}.oraclecloud.com${oci_objectstorage_preauthrequest.app_archive_download.access_uri}"
      app_port           = local.app_port
      region             = var.region
      model              = var.model
      short_project_id   = local.short_term_project_id
      long_project_id    = local.long_term_project_id
      tenancy_ocid       = local.resolved_tenancy_ocid
      compartment_ocid   = local.resolved_compartment_ocid
      iam_user_ocid      = oci_identity_user.app_user.id
      iam_fingerprint    = oci_identity_api_key.app_user_key.fingerprint
      iam_private_key    = tls_private_key.iam_api_key.private_key_pem
    }))
  }

  depends_on = [
    oci_identity_policy.genai_policy,
    oci_objectstorage_object.app_archive,
    oci_objectstorage_preauthrequest.app_archive_download
  ]
}
