output "public_url" {
  description = "URL publica da aplicacao"
  value       = "http://${oci_core_instance.app_vm.public_ip}:${local.app_port}"
}

output "vm_public_ip" {
  description = "IP publico da VM"
  value       = oci_core_instance.app_vm.public_ip
}

output "vm_ocid" {
  description = "OCID da instancia"
  value       = oci_core_instance.app_vm.id
}

output "short_term_project_id" {
  description = "Project ID usado para memoria de curto prazo"
  value       = local.short_term_project_id
}

output "long_term_project_id" {
  description = "Project ID usado para memoria de longo prazo"
  value       = local.long_term_project_id
}

output "iam_api_key_fingerprint" {
  description = "Fingerprint da IAM API key criada"
  value       = oci_identity_api_key.app_user_key.fingerprint
}

output "iam_api_user_ocid" {
  description = "OCID do usuario IAM criado para a aplicacao"
  value       = oci_identity_user.app_user.id
}

output "generated_ssh_private_key_pem" {
  description = "Chave privada gerada pelo Terraform (apenas quando ssh_public_key nao for informada)."
  value       = var.expose_private_outputs && trimspace(var.ssh_public_key) == "" ? tls_private_key.ssh_access[0].private_key_pem : null
  sensitive   = true
}

output "iam_private_key_pem" {
  description = "Chave privada da IAM API key criada para uso da aplicacao"
  value       = var.expose_private_outputs ? tls_private_key.iam_api_key.private_key_pem : null
  sensitive   = true
}
