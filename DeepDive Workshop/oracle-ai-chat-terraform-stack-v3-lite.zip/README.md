# Oracle AI Chat Terraform Stack

Este stack sobe toda a estrutura da aplicacao de chat em OCI com bootstrap automatico na VM:

- VCN/Subnet publica totalmente aberta
- VM `VM.Standard.E5.Flex`
- IAM user + IAM API key
- IAM group + policy para Generative AI
- IDs de projeto (short/long term) gerados e gravados na VM
- Upload do app (`local-enterprise-chat`) para Object Storage
- Deploy automatico via cloud-init + systemd

O codigo da aplicacao fica embutido no proprio stack em:

- `app/local-enterprise-chat`

## Entradas principais

A configuracao minima para o chat responder no modelo remoto:

- `region`
- `model`

Exemplo (`terraform.tfvars`):

```hcl
region = "sa-saopaulo-1"
model  = "meta.llama-3.3-70b-instruct"
```

## Credenciais OCI

A autenticacao OCI continua vindo do provider (perfil local, variaveis de ambiente ou Resource Manager).

Para uso local, normalmente voce informa tambem:

- `tenancy_ocid`
- `compartment_ocid` (opcional; se vazio usa tenancy)

## Deploy

```bash
terraform init
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars
```

## Resultado

Veja os outputs:

- `public_url` (aplicacao publica)
- `vm_public_ip`
- `short_term_project_id`
- `long_term_project_id`
- `iam_api_key_fingerprint`

Arquivos gravados na VM:

- `/opt/oracle-ai-chat/config.json`
- `/opt/oracle-ai-chat/runtime/projects.json`
- `/opt/oracle-ai-chat/runtime/iam_api_key.json`
- `/opt/oracle-ai-chat/runtime/oci_api_private.pem`

## Observacao importante

Este stack usa autenticacao IAM assinada (API key IAM com assinatura RSA) no endpoint nativo do Generative AI (`/20231130/actions/chat`), sem `Bearer` de OpenAI.
