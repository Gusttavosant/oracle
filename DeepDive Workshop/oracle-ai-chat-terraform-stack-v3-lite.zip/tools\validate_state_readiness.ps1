param(
  [Parameter(Mandatory = $true)]
  [string]$StateFile
)

$ErrorActionPreference = "Stop"

if (!(Test-Path -LiteralPath $StateFile)) {
  throw "State file not found: $StateFile"
}

$raw = Get-Content -LiteralPath $StateFile -Raw
$state = $raw | ConvertFrom-Json -Depth 100

function Get-ResourceInstance {
  param([string]$Type, [string]$Name)
  $res = $state.resources | Where-Object { $_.type -eq $Type -and $_.name -eq $Name } | Select-Object -First 1
  if ($null -eq $res -or $null -eq $res.instances -or $res.instances.Count -eq 0) {
    return $null
  }
  return $res.instances[0]
}

function Assert-Cond {
  param([bool]$Cond, [string]$Ok, [string]$Fail)
  if ($Cond) {
    [PSCustomObject]@{ status = "PASS"; detail = $Ok }
  } else {
    [PSCustomObject]@{ status = "FAIL"; detail = $Fail }
  }
}

$results = @()

$vm = Get-ResourceInstance -Type "oci_core_instance" -Name "app_vm"
$rt = Get-ResourceInstance -Type "oci_core_route_table" -Name "app_rt"
$sl = Get-ResourceInstance -Type "oci_core_security_list" -Name "app_sl"
$subnet = Get-ResourceInstance -Type "oci_core_subnet" -Name "app_subnet"
$igw = Get-ResourceInstance -Type "oci_core_internet_gateway" -Name "app_igw"

$results += Assert-Cond -Cond ($null -ne $vm) `
  -Ok "VM instance exists in state" `
  -Fail "VM instance missing in state"

if ($null -ne $vm) {
  $results += Assert-Cond -Cond ($vm.attributes.state -eq "RUNNING") `
    -Ok "VM state is RUNNING" `
    -Fail ("VM state is '{0}'" -f $vm.attributes.state)

  $pubIp = [string]$vm.attributes.public_ip
  $results += Assert-Cond -Cond (![string]::IsNullOrWhiteSpace($pubIp)) `
    -Ok ("VM has public IP: {0}" -f $pubIp) `
    -Fail "VM has no public IP"

  $userDataB64 = [string]$vm.attributes.metadata.user_data
  $userData = ""
  if (![string]::IsNullOrWhiteSpace($userDataB64)) {
    $userData = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($userDataB64))
  }

  $results += Assert-Cond -Cond ($userData -match "ExecStart=/usr/bin/node server\.js") `
    -Ok "systemd uses node server.js" `
    -Fail "systemd ExecStart not found in user_data"

  $results += Assert-Cond -Cond ($userData -match "Environment=HOST=0\.0\.0\.0") `
    -Ok "HOST=0.0.0.0 configured" `
    -Fail "HOST=0.0.0.0 missing"

  $results += Assert-Cond -Cond ($userData -match "/api/health") `
    -Ok "local healthcheck is present in bootstrap" `
    -Fail "local healthcheck missing in bootstrap"
}

$results += Assert-Cond -Cond ($null -ne $igw) `
  -Ok "Internet Gateway exists" `
  -Fail "Internet Gateway missing"

if ($null -ne $rt -and $null -ne $igw) {
  $hasDefaultRoute = $false
  foreach ($r in $rt.attributes.route_rules) {
    if ($r.destination -eq "0.0.0.0/0" -and $r.network_entity_id -eq $igw.attributes.id) {
      $hasDefaultRoute = $true
      break
    }
  }
  $results += Assert-Cond -Cond $hasDefaultRoute `
    -Ok "Route table has default route to IGW" `
    -Fail "No default route to IGW in route table"
} else {
  $results += Assert-Cond -Cond $false `
    -Ok "" `
    -Fail "Route table or IGW missing"
}

if ($null -ne $subnet) {
  $results += Assert-Cond -Cond ($subnet.attributes.prohibit_internet_ingress -eq $false) `
    -Ok "Subnet allows internet ingress" `
    -Fail "Subnet blocks internet ingress"

  $results += Assert-Cond -Cond ($subnet.attributes.prohibit_public_ip_on_vnic -eq $false) `
    -Ok "Subnet allows public IP on VNIC" `
    -Fail "Subnet blocks public IP on VNIC"
}

if ($null -ne $sl) {
  $openIngress = $false
  foreach ($r in $sl.attributes.ingress_security_rules) {
    if ($r.source -eq "0.0.0.0/0" -and ($r.protocol -eq "all" -or $r.protocol -eq "6")) {
      $openIngress = $true
      break
    }
  }
  $results += Assert-Cond -Cond $openIngress `
    -Ok "Security list has internet ingress rule" `
    -Fail "Security list lacks 0.0.0.0/0 ingress"
}

$outputs = $state.outputs
if ($null -ne $outputs.public_url) {
  $results += Assert-Cond -Cond (![string]::IsNullOrWhiteSpace([string]$outputs.public_url.value)) `
    -Ok ("public_url output: {0}" -f $outputs.public_url.value) `
    -Fail "public_url output empty"
}

$results | Format-Table -AutoSize

$failed = @($results | Where-Object { $_.status -eq "FAIL" })
if ($failed.Count -gt 0) {
  exit 2
}
exit 0
