let currentProjectId = "";
let selectedConversationId = "";
let toastStack = null;

async function api(path) {
  const res = await fetch(path, { headers: { "Content-Type": "application/json" } });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function getToastStack() {
  if (toastStack) return toastStack;
  toastStack = document.createElement("div");
  toastStack.className = "toast-stack";
  document.body.appendChild(toastStack);
  return toastStack;
}

function showErrorPopup(message) {
  const stack = getToastStack();
  const toast = document.createElement("div");
  toast.className = "toast error";
  toast.innerHTML = `<span class="toast-title">Erro</span>${String(message || "Falha inesperada.")}`;
  stack.appendChild(toast);
  setTimeout(() => {
    toast.remove();
    if (!stack.children.length) {
      stack.remove();
      toastStack = null;
    }
  }, 5200);
}

function setMeta(text) {
  document.getElementById("meta").textContent = text;
}

function setSelectedConversation(text) {
  document.getElementById("selectedConversation").textContent = text;
}

function formatDate(value) {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return String(value);
  return d.toLocaleString("pt-BR");
}

function renderHistory(messages) {
  const wrap = document.getElementById("historyResults");
  wrap.innerHTML = "";

  if (!Array.isArray(messages) || !messages.length) {
    wrap.innerHTML = '<div class="doc-item">Sem mensagens nesta conversa.</div>';
    return;
  }

  messages.forEach((m) => {
    const row = document.createElement("div");
    row.className = `history-row ${m.role === "user" ? "user" : "assistant"}`;

    const role = m.role === "user" ? "user" : "assistant";
    row.textContent = `${role}: ${m.content || ""}`;
    wrap.appendChild(row);
  });
}

async function fetchConversationMessages(projectId, conversationId) {
  try {
    return await api(`/api/projects/${encodeURIComponent(projectId)}/conversations/${encodeURIComponent(conversationId)}/messages`);
  } catch {
    return api(`/api/conversations/${encodeURIComponent(conversationId)}/messages`);
  }
}

async function openConversation(conversation) {
  selectedConversationId = conversation.id;

  document.querySelectorAll(".project-folder-item").forEach((el) => {
    el.classList.toggle("active", el.dataset.id === selectedConversationId);
  });

  const messages = await fetchConversationMessages(currentProjectId, selectedConversationId);
  renderHistory(messages);

  setSelectedConversation(`Conversa: ${conversation.id} | titulo: ${conversation.title || "Nova conversa"} | mensagens: ${conversation.message_count || messages.length || 0}`);
  setMeta(`Historico carregado para ${conversation.id}.`);
}

function renderConversationFolders(rows) {
  const wrap = document.getElementById("projectConversationList");
  wrap.innerHTML = "";

  if (!rows.length) {
    wrap.innerHTML = '<div class="doc-item">Nenhuma conversa encontrada para este project.</div>';
    return;
  }

  rows.forEach((c) => {
    const item = document.createElement("div");
    item.className = "conversation-item project-folder-item";
    item.dataset.id = c.id;
    item.innerHTML = [
      `<div><strong>${c.id}</strong></div>`,
      `<small>titulo=${c.title || "Nova conversa"}</small>`,
      `<small>mensagens=${c.message_count || 0} | ultimo=${formatDate(c.last_message_at)}</small>`
    ].join("");

    item.onclick = async () => {
      try {
        await openConversation(c);
      } catch (err) {
        setMeta(`Erro ao abrir historico: ${err.message || err}`);
        showErrorPopup(`Erro ao abrir historico: ${err.message || err}`);
      }
    };

    wrap.appendChild(item);
  });
}

async function loadProjectConversations() {
  currentProjectId = document.getElementById("projectInput").value.trim();
  if (!currentProjectId) {
    setMeta("Informe um project id.");
    showErrorPopup("Informe um project id.");
    return;
  }

  selectedConversationId = "";
  setSelectedConversation("Nenhuma conversa selecionada.");
  document.getElementById("historyResults").innerHTML = "";

  const rows = await api(`/api/projects/${encodeURIComponent(currentProjectId)}/conversations`);
  renderConversationFolders(rows);
  setMeta(`${rows.length} conversa(s) encontrada(s). Clique em uma pasta para abrir o historico.`);
}

document.getElementById("loadBtn").onclick = async () => {
  try {
    await loadProjectConversations();
  } catch (err) {
    setMeta(`Erro: ${err.message || err}`);
    showErrorPopup(`Erro: ${err.message || err}`);
  }
};

window.onload = async () => {
  try {
    const health = await api("/api/health");
    if (health.project_id) {
      document.getElementById("projectInput").value = health.project_id;
    }
    setMeta("Pronto para consultar conversations por project.");
  } catch (err) {
    setMeta(`Falha ao iniciar: ${err.message || err}`);
    showErrorPopup(`Falha ao iniciar: ${err.message || err}`);
  }
};
