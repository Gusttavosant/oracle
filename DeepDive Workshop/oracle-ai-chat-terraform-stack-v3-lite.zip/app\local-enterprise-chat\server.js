﻿const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
let pdfParseLib = null;
try {
  pdfParseLib = require("pdf-parse");
} catch {
  pdfParseLib = null;
}
const PDFParseClass = pdfParseLib?.PDFParse || pdfParseLib?.default?.PDFParse || null;

const APP_DIR = __dirname;
const PUBLIC_DIR = path.join(APP_DIR, "public");
const DATA_DIR = path.join(APP_DIR, "data");
const RUNTIME_DIR = path.join(APP_DIR, "runtime");
const CHAT_DB_FILE = path.join(DATA_DIR, "chat-db.json");
const VECTOR_DB_FILE = path.join(DATA_DIR, "vector-db.json");
const CONFIG_FILE = path.join(APP_DIR, "config.json");
const IAM_API_KEY_FILE = path.join(RUNTIME_DIR, "iam_api_key.json");
const OCI_API_PRIVATE_KEY_FILE = path.join(RUNTIME_DIR, "oci_api_private.pem");
const ENV_FILE_LOCAL = path.join(APP_DIR, ".env");
const ENV_FILE_PARENT = path.join(APP_DIR, "..", ".env");

const PORT = Number.parseInt(process.env.PORT || "8080", 10) || 8080;
const BIND_HOST = process.env.HOST || "127.0.0.1";
const CHUNK_CHARS = 200;
const MAX_DOC_CHARS = 500_000;
const MAX_UPLOAD_BYTES = 8_000_000;
const HISTORY_MAX_MESSAGES = 16;

function loadConfig() {
  const raw = fs.readFileSync(CONFIG_FILE, "utf8").replace(/^\uFEFF/, "");
  return JSON.parse(raw);
}

function loadEnvFile(filePath) {
  if (!fs.existsSync(filePath)) return {};
  const out = {};
  const raw = fs.readFileSync(filePath, "utf8").replace(/^\uFEFF/, "");
  for (const line of raw.split(/\r?\n/)) {
    const clean = line.trim();
    if (!clean || clean.startsWith("#")) continue;
    const idx = clean.indexOf("=");
    if (idx <= 0) continue;
    const key = clean.slice(0, idx).trim();
    let value = clean.slice(idx + 1).trim();
    if ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    out[key] = value;
  }
  return out;
}

const cfg = loadConfig();
const envMerged = { ...loadEnvFile(ENV_FILE_PARENT), ...loadEnvFile(ENV_FILE_LOCAL), ...process.env };
const CHAT_MODEL = cfg.model_id;
const EMBEDDING_MODEL = cfg.embedding_model || "cohere.embed-multilingual-v3.0";
const HOST = `https://inference.generativeai.${cfg.region}.oci.oraclecloud.com`;
const OCI_NATIVE_BASE = cfg.native_base_url || `${HOST}/20231130/actions`;

function loadIamSignerContext() {
  if (!fs.existsSync(IAM_API_KEY_FILE) || !fs.existsSync(OCI_API_PRIVATE_KEY_FILE)) return null;
  const iamRaw = fs.readFileSync(IAM_API_KEY_FILE, "utf8").replace(/^\uFEFF/, "");
  const iam = safeJsonParse(iamRaw, null);
  if (!iam) return null;

  const privateKeyPem = fs.readFileSync(OCI_API_PRIVATE_KEY_FILE, "utf8");
  const userOcid = String(iam.user_ocid || "").trim();
  const fingerprint = String(iam.fingerprint || "").trim();
  const tenancyOcid = String(iam.tenancy_ocid || cfg.tenancy_ocid || "").trim();
  const compartmentOcid = String(iam.compartment_ocid || cfg.compartment_ocid || "").trim();
  const region = String(iam.region || cfg.region || "").trim();

  if (!userOcid || !fingerprint || !tenancyOcid || !compartmentOcid || !privateKeyPem || !region) return null;

  return {
    name: `iam-signed-${region}`,
    region,
    host: `inference.generativeai.${region}.oci.oraclecloud.com`,
    nativeBase: `https://inference.generativeai.${region}.oci.oraclecloud.com/20231130/actions`,
    userOcid,
    fingerprint,
    tenancyOcid,
    compartmentOcid,
    privateKeyPem,
    keyId: `${tenancyOcid}/${userOcid}/${fingerprint}`,
  };
}

const AUTH_CONTEXTS = [loadIamSignerContext()].filter(Boolean);

function nowIso() {
  return new Date().toISOString();
}

function detectLanguage(text) {
  const sample = String(text || "").toLowerCase().slice(0, 4000);
  const ptHits = (sample.match(/\b(que|de|do|da|na|não|cart[aã]o|fase|grupos)\b/g) || []).length;
  const enHits = (sample.match(/\b(the|and|group|stage|yellow|card|suspension|match)\b/g) || []).length;
  if (enHits > ptHits + 1) return "en";
  if (ptHits > enHits + 1) return "pt";
  return "unknown";
}

function ensureDataFiles() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(CHAT_DB_FILE)) {
    fs.writeFileSync(CHAT_DB_FILE, JSON.stringify({ conversations: [], messages: [] }, null, 2), "utf8");
  }
  if (!fs.existsSync(VECTOR_DB_FILE)) {
    fs.writeFileSync(VECTOR_DB_FILE, JSON.stringify({ documents: [], chunks: [] }, null, 2), "utf8");
  }
}

function readJson(filePath) {
  ensureDataFiles();
  return JSON.parse(fs.readFileSync(filePath, "utf8").replace(/^\uFEFF/, ""));
}

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2), "utf8");
}

function readChatDb() {
  return readJson(CHAT_DB_FILE);
}

function writeChatDb(db) {
  writeJson(CHAT_DB_FILE, db);
}

function readVectorDb() {
  return readJson(VECTOR_DB_FILE);
}

function writeVectorDb(db) {
  writeJson(VECTOR_DB_FILE, db);
}

function upsertConversation(id, title = "Nova conversa", projectId = cfg.project_id || "default-project") {
  const db = readChatDb();
  const found = db.conversations.find((c) => c.id === id);
  if (!found) {
    db.conversations.push({ id, title, project_id: projectId, created_at: nowIso() });
  } else if (title && found.title === "Nova conversa") {
    found.title = title;
    if (!found.project_id) found.project_id = projectId;
  } else if (!found.project_id) {
    found.project_id = projectId;
  }
  writeChatDb(db);
}

function addMessage(conversationId, role, content, metadata) {
  const db = readChatDb();
  db.messages.push({
    id: crypto.randomUUID(),
    conversation_id: conversationId,
    role,
    content,
    metadata: metadata || {},
    created_at: nowIso(),
  });
  writeChatDb(db);
}

function listConversations() {
  const db = readChatDb();
  return db.conversations.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
}

function listConversationsByProject(projectId) {
  const db = readChatDb();
  const project = String(projectId || "").trim();
  if (!project) return [];
  const messages = db.messages;
  return db.conversations
    .filter((c) => String(c.project_id || cfg.project_id || "default-project") === project)
    .map((c) => {
      const own = messages.filter((m) => m.conversation_id === c.id);
      const last = own.length ? own[own.length - 1].created_at : c.created_at;
      return {
        ...c,
        message_count: own.length,
        last_message_at: last || c.created_at,
      };
    })
    .sort((a, b) => String(b.last_message_at || "").localeCompare(String(a.last_message_at || "")));
}

function getConversationMessages(conversationId) {
  const db = readChatDb();
  return db.messages.filter((m) => m.conversation_id === conversationId);
}

function listKnowledgeDocs(conversationId) {
  const db = readVectorDb();
  const docs = db.documents.filter((d) => d.conversation_id === conversationId);
  return docs.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
}

function chunkTextByChars(text, chunkChars = CHUNK_CHARS) {
  const normalized = String(text || "").replace(/\s+/g, " ").trim();
  const chunks = [];
  for (let i = 0; i < normalized.length; i += chunkChars) {
    const group = normalized.slice(i, i + chunkChars).trim();
    if (group) chunks.push(group);
  }
  return chunks;
}

function safeJsonParse(raw, fallback) {
  try {
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function stripHtml(text) {
  return String(text || "")
    .replace(/<[^>]*>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

function decodeBase64ToBuffer(base64) {
  return Buffer.from(String(base64 || ""), "base64");
}

function cleanExtractedText(text) {
  return String(text || "")
    .replace(/\u0000/g, " ")
    .replace(/\r/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function clampInt(value, min, max, fallback) {
  const n = Number.parseInt(String(value || ""), 10);
  if (Number.isNaN(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

async function extractDocumentText({ filename, mimeType, content, contentBase64 }) {
  if (contentBase64) {
    const buffer = decodeBase64ToBuffer(contentBase64);
    if (!buffer.length) throw new Error("file content is empty");
    if (buffer.length > MAX_UPLOAD_BYTES) throw new Error("file is too large (max 8MB)");

    const lowerName = String(filename || "").toLowerCase();
    const lowerType = String(mimeType || "").toLowerCase();
    const isPdf = lowerName.endsWith(".pdf") || lowerType.includes("application/pdf");

    if (isPdf) {
      if (!PDFParseClass) {
        throw new Error("pdf parser is unavailable in this deployment; upload txt/markdown or install optional dependency");
      }
      const parser = new PDFParseClass({ data: buffer });
      const parsed = await parser.getText();
      await parser.destroy();
      const text = cleanExtractedText(parsed?.text || "");
      if (!text) throw new Error("could not extract text from pdf");
      return text;
    }

    return cleanExtractedText(buffer.toString("utf8"));
  }

  if (!content || !String(content).trim()) throw new Error("file content is empty");
  return cleanExtractedText(String(content));
}

function cosineSimilarity(a, b) {
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length || a.length === 0) return -1;
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (na === 0 || nb === 0) return -1;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

function lexicalOverlapScore(query, text) {
  const q = new Set(String(query || "").toLowerCase().split(/\W+/).filter((t) => t.length > 2));
  const t = new Set(String(text || "").toLowerCase().split(/\W+/).filter((w) => w.length > 2));
  if (!q.size || !t.size) return 0;
  let hits = 0;
  for (const word of q) {
    if (t.has(word)) hits += 1;
  }
  return hits / q.size;
}

async function createEmbedding(text) {
  void text;
  // Sem endpoint OpenAI/bearer: fallback para busca lexical local.
  return null;
}

function randomConversationId() {
  return `local-${crypto.randomUUID()}`;
}

function buildPrompt({ message, knowledgeSnippets, webResults, useKnowledge, useWebSearch }) {
  const instructions = [
    "Voce e um assistente de IA para workshop tecnico.",
    "Responda em portugues claro e objetivo.",
  ];

  if (useKnowledge) instructions.push("Use primeiro a base de conhecimento quando houver contexto relevante.");
  if (useWebSearch) instructions.push("Considere resultados de busca web como complemento, nao como verdade absoluta.");

  const kb = knowledgeSnippets.length
    ? knowledgeSnippets
        .map((k, idx) => `K${idx + 1} | arquivo=${k.file} | score=${k.score.toFixed(3)}\n${k.text}`)
        .join("\n\n")
    : "(sem contexto recuperado)";

  const wb = webResults.length
    ? webResults
        .map((w, idx) => `W${idx + 1}: ${w.title}\nURL: ${w.url}\nResumo: ${w.snippet}`)
        .join("\n\n")
    : "(sem resultados de web)";

  return `
INSTRUCOES:
${instructions.join("\n")}

BASE_DE_CONHECIMENTO:
${kb}

WEB_SEARCH:
${wb}

PERGUNTA:
${message}
`.trim();
}

function buildToolTrace({ useKnowledge, useWebSearch, message, knowledge, webResults }) {
  const toolTrace = [];
  if (useKnowledge) {
    toolTrace.push({
      tool: "knowledge_retrieval",
      query: message,
      items: knowledge.snippets.slice(0, 3).map((k) => ({
        title: k.file,
        text: k.text.slice(0, 220),
      })),
    });
  }
  if (useWebSearch) {
    toolTrace.push({
      tool: "duckduckgo_search",
      query: message,
      items: webResults.slice(0, 5).map((r) => ({
        title: r.title,
        url: r.url,
        text: r.snippet,
      })),
    });
  }
  return toolTrace;
}

function makeRequestTarget(urlObj) {
  const q = urlObj.search || "";
  return `${urlObj.pathname}${q}`;
}

function sha256Base64(content) {
  return crypto.createHash("sha256").update(content).digest("base64");
}

function buildSignedHeaders(urlObj, method, body, authCtx, isoDate) {
  const host = urlObj.host;
  const requestTarget = `${method.toLowerCase()} ${makeRequestTarget(urlObj)}`;
  const contentSha256 = sha256Base64(body);
  const contentLength = Buffer.byteLength(body, "utf8");
  const signingString = [
    `(request-target): ${requestTarget}`,
    `host: ${host}`,
    `date: ${isoDate}`,
    "content-type: application/json",
    `content-length: ${contentLength}`,
    `x-content-sha256: ${contentSha256}`,
  ].join("\n");
  const signature = crypto.sign("RSA-SHA256", Buffer.from(signingString, "utf8"), authCtx.privateKeyPem).toString("base64");
  const authorization = [
    'Signature version="1"',
    `keyId="${authCtx.keyId}"`,
    'algorithm="rsa-sha256"',
    'headers="(request-target) host date content-type content-length x-content-sha256"',
    `signature="${signature}"`,
  ].join(",");

  return {
    host,
    date: isoDate,
    "content-type": "application/json",
    "content-length": String(contentLength),
    "x-content-sha256": contentSha256,
    authorization,
  };
}

async function ociSignedJsonPost(fullUrl, payload, authCtx) {
  const urlObj = new URL(fullUrl);
  const body = JSON.stringify(payload || {});
  const date = new Date().toUTCString();
  const headers = buildSignedHeaders(urlObj, "POST", body, authCtx, date);

  const res = await fetch(fullUrl, {
    method: "POST",
    headers,
    body,
  });
  const raw = await res.text();
  return {
    ok: res.ok,
    status: res.status,
    data: safeJsonParse(raw, { raw }),
    raw,
  };
}

function extractTextFromChatData(data) {
  if (!data || typeof data !== "object") return "";
  const direct = data?.chatResponse?.text;
  if (typeof direct === "string" && direct.trim()) return direct.trim();

  const generic =
    data?.chatResponse?.choices?.[0]?.message?.content?.find((c) => typeof c?.text === "string")?.text ||
    data?.chatResponse?.choices?.[0]?.message?.content?.[0]?.text ||
    data?.chatResponse?.message?.content?.find((c) => typeof c?.text === "string")?.text ||
    data?.chatResponse?.message?.content?.[0]?.text;
  if (typeof generic === "string" && generic.trim()) return generic.trim();

  const fallback = data?.chatResponse?.message?.content || data?.chatResponse?.message || data?.chatResponse;
  if (typeof fallback === "string") return fallback.trim();
  return "";
}

async function callModelViaNativeChat(promptInput, authCtx) {
  const payload = {
    compartmentId: authCtx.compartmentOcid,
    servingMode: {
      servingType: "ON_DEMAND",
      modelId: CHAT_MODEL,
    },
    chatRequest: {
      apiFormat: "GENERIC",
      isStream: false,
      maxTokens: 1000,
      temperature: 0.1,
      messages: [
        {
          role: "USER",
          content: [{ type: "TEXT", text: String(promptInput || "") }],
        },
      ],
    },
  };

  const endpoint = `${authCtx.nativeBase}/chat`;
  const result = await ociSignedJsonPost(endpoint, payload, authCtx);
  const text = extractTextFromChatData(result.data);
  return {
    ok: result.ok && !!text,
    text,
    status: result.status,
    endpoint,
    data: result.data,
  };
}

async function callModelWithFallback(promptInput, conversationId) {
  void conversationId;
  const attempts = [];
  for (const ctx of AUTH_CONTEXTS) {
    try {
      const out = await callModelViaNativeChat(promptInput, ctx);
      attempts.push({ endpoint: out.endpoint, status: out.status, ok: out.ok, context: ctx.name });
      if (out.ok) {
        return {
          ok: true,
          text: out.text,
          endpoint: out.endpoint,
          context: ctx.name,
          attempts,
        };
      }
    } catch (err) {
      attempts.push({ endpoint: `${ctx.nativeBase}/chat`, status: 0, ok: false, context: ctx.name, error: String(err) });
    }
  }

  return {
    ok: false,
    text: "",
    endpoint: null,
    context: null,
    attempts,
  };
}

function chunkForPseudoStream(text, chunkSize = 28) {
  const chunks = [];
  const source = String(text || "");
  for (let i = 0; i < source.length; i += chunkSize) {
    chunks.push(source.slice(i, i + chunkSize));
  }
  return chunks;
}

function getRecentConversationMessages(conversationId, maxItems = HISTORY_MAX_MESSAGES) {
  const history = getConversationMessages(conversationId)
    .filter((m) => (m.role === "user" || m.role === "assistant") && String(m.content || "").trim())
    .sort((a, b) => String(a.created_at || "").localeCompare(String(b.created_at || "")));
  return history.slice(Math.max(0, history.length - maxItems));
}

function buildHistoryForFallback(conversationId) {
  return getRecentConversationMessages(conversationId)
    .map((m) => `${m.role === "assistant" ? "assistente" : "usuário"}: ${String(m.content || "")}`)
    .join("\n");
}

function buildAgentSystemPrompt(docLanguages) {
  return [
    "Você é um agente especialista na Copa do Mundo FIFA 2026.",
    "Responda em português de forma objetiva e útil.",
    "Para cumprimentos e small talk, responda cordialmente em uma frase curta e convide o usuário para uma pergunta sobre Copa 2026.",
    "Use o histórico recente da conversa para manter contexto entre turnos.",
    "Se a pergunta for referencial (ex.: 'do que estávamos falando?', 'isso', 'aquele ponto'), responda com base na última troca relevante.",
    "Se a pergunta não for sobre Copa do Mundo 2026 (times, formato, grupos, calendário, regras, sedes, jogadores, estatísticas, documentos enviados sobre o tema), recuse educadamente e peça para reformular dentro desse tema.",
    "Use tools apenas quando necessário.",
    "Não use tools para cumprimento, conversa casual, opinião genérica ou perguntas simples sem necessidade de dados externos.",
    "Para fatos estáveis e amplamente conhecidos da Copa 2026, responda direto sem tool.",
    "Só use tool quando faltar informação confiável, quando precisar de dados muito atuais, ou quando o usuário pedir fontes.",
    "Use knowledge_retrieval somente quando a resposta depender de arquivos enviados.",
    "Use duckduckgo_search somente para fatos externos/atuais que não estejam nos arquivos.",
    "Se houver documentos em inglês e pergunta em português, traduza a query para inglês ao chamar knowledge_retrieval.",
    `Idiomas detectados nos documentos da conversa: ${docLanguages.join(", ") || "none"}.`,
  ].join(" ");
}

function buildScopedUserPrompt(message, docLanguages, historyText = "") {
  const historyBlock = historyText
    ? ["", "Histórico recente da conversa:", historyText].join("\n")
    : "";
  return [
    "Siga estas instruções:",
    buildAgentSystemPrompt(docLanguages),
    historyBlock,
    "",
    "Pergunta do usuário:",
    String(message || ""),
  ].join("\n");
}

async function runLangChainAgent({ conversationId, message, allowKnowledge, allowWebSearch }) {
  if (!AUTH_CONTEXTS.length) {
    const attempts = [{ endpoint: "no-auth-context", status: 0, ok: false }];
    return {
      ok: false,
      answer: buildOfflineFallback(message, [], [], attempts),
      toolTrace: [],
      model_endpoint: null,
      model_context: null,
      attempts,
    };
  }

  const docs = listKnowledgeDocs(conversationId);
  const docLanguages = [...new Set(docs.map((d) => d.language).filter(Boolean))];
  const historyForFallback = buildHistoryForFallback(conversationId);
  const scopedPrompt = buildScopedUserPrompt(message, docLanguages, historyForFallback);
  const knowledge = allowKnowledge ? await retrieveKnowledgeContext(conversationId, message, 4) : { snippets: [], usedSemantic: false };
  const webResults = allowWebSearch ? await searchDuckDuckGo(message, 5) : [];
  const toolTrace = buildToolTrace({
    useKnowledge: allowKnowledge,
    useWebSearch: allowWebSearch,
    message,
    knowledge,
    webResults,
  });

  const prompt = buildPrompt({
    message: scopedPrompt,
    knowledgeSnippets: knowledge.snippets,
    webResults,
    useKnowledge: allowKnowledge,
    useWebSearch: allowWebSearch,
  });

  const direct = await callModelWithFallback(prompt, conversationId);
  const answer = direct.ok
    ? direct.text
    : buildOfflineFallback(message, knowledge.snippets, webResults, direct.attempts);

  return {
    ok: direct.ok,
    answer: String(answer || ""),
    toolTrace,
    model_endpoint: direct.endpoint,
    model_context: direct.context,
    attempts: direct.attempts,
  };
}

async function modelDiag() {
  const probePrompt = "Responda apenas: OK";
  const probe = await callModelWithFallback(probePrompt, randomConversationId());
  return {
    model: CHAT_MODEL,
    region: cfg.region,
    compartment_ocid: cfg.compartment_ocid || null,
    auth_contexts: AUTH_CONTEXTS.map((c) => ({
      name: c.name,
      region: c.region,
      tenancy_ocid: c.tenancyOcid,
      compartment_ocid: c.compartmentOcid,
    })),
    ok: probe.ok,
    working_endpoint: probe.endpoint,
    working_context: probe.context,
    attempts: probe.attempts,
    checked_at: nowIso(),
  };
}

function buildOfflineFallback(message, knowledgeSnippets, webResults, attempts) {
  const lines = [
    "Nao foi possivel consultar o modelo remoto agora.",
    "",
    "Diagnostico de endpoints testados:",
  ];

  for (const a of attempts || []) {
    lines.push(`- ${a.endpoint} => status=${a.status} ok=${a.ok}`);
  }

  lines.push("", `Pergunta: ${message}`);

  if (knowledgeSnippets.length) {
    lines.push("", "Trechos da base local:");
    for (const item of knowledgeSnippets.slice(0, 3)) {
      lines.push(`- [${item.file}] ${item.text.slice(0, 240)}${item.text.length > 240 ? "..." : ""}`);
    }
  }

  if (webResults.length) {
    lines.push("", "Resultados web encontrados:");
    for (const r of webResults.slice(0, 3)) {
      lines.push(`- ${r.title} (${r.url})`);
    }
  }

  lines.push("", "Ajuste recomendado: validar policy IAM, user/fingerprint/chave PEM e endpoint nativo GenAI.");
  return lines.join("\n");
}

async function retrieveKnowledgeContext(conversationId, query, topK = 4) {
  const db = readVectorDb();
  const chunks = db.chunks.filter((c) => c.conversation_id === conversationId);
  if (!chunks.length) return { snippets: [], usedSemantic: false };

  const queryEmbedding = await createEmbedding(query);
  const scored = chunks.map((chunk) => {
    const score = queryEmbedding
      ? cosineSimilarity(queryEmbedding, chunk.embedding)
      : lexicalOverlapScore(query, chunk.text);
    return { chunk, score };
  });

  scored.sort((a, b) => b.score - a.score);
  let picked = scored.slice(0, topK).filter((s) => (s.score || 0) > 0);
  if (!picked.length) {
    picked = scored.slice(0, topK);
  }

  return {
    snippets: picked.map((p) => ({
      file: p.chunk.filename,
      text: p.chunk.text,
      score: p.score,
    })),
    usedSemantic: !!queryEmbedding,
  };
}

async function searchDuckDuckGo(query, maxResults = 5) {
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
  try {
    const res = await fetch(url, {
      method: "GET",
      headers: { "User-Agent": "Mozilla/5.0" },
    });
    const html = await res.text();
    const items = [];
    const regex = /<a rel="nofollow" class="result__a" href="([^"]+)">([\s\S]*?)<\/a>[\s\S]*?<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
    let match;
    while ((match = regex.exec(html)) && items.length < maxResults) {
      items.push({
        title: stripHtml(match[2]),
        url: stripHtml(match[1]),
        snippet: stripHtml(match[3]),
      });
    }
    return items;
  } catch {
    return [];
  }
}

async function ingestDocument({ conversationId, filename, mimeType, content, contentBase64 }) {
  if (!conversationId) throw new Error("conversation_id is required");
  if (!filename) throw new Error("filename is required");
  const rawText = await extractDocumentText({ filename, mimeType, content, contentBase64 });
  const text = rawText.slice(0, MAX_DOC_CHARS);
  const language = detectLanguage(text);
  const chunks = chunkTextByChars(text, CHUNK_CHARS);
  if (!chunks.length) throw new Error("no chunks generated from file");

  const vectorDb = readVectorDb();
  const documentId = crypto.randomUUID();

  vectorDb.documents.push({
    id: documentId,
    conversation_id: conversationId,
    filename,
    language,
    chunk_count: chunks.length,
    created_at: nowIso(),
  });

  for (let i = 0; i < chunks.length; i++) {
    const chunkText = chunks[i];
    const embedding = await createEmbedding(chunkText);
    vectorDb.chunks.push({
      id: crypto.randomUUID(),
      document_id: documentId,
      conversation_id: conversationId,
      filename,
      language,
      chunk_index: i,
      text: chunkText,
      embedding,
      created_at: nowIso(),
    });
  }

  writeVectorDb(vectorDb);
  return { document_id: documentId, filename, chunks: chunks.length };
}

function sendJson(res, status, obj) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
}

function parseBody(req) {
  return new Promise((resolve) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 10_000_000) req.destroy();
    });
    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        resolve({});
      }
    });
  });
}

function serveStatic(req, res) {
  const reqPath = new URL(req.url, "http://127.0.0.1").pathname;
  const rel = reqPath === "/" ? "/index.html" : reqPath === "/chunks" ? "/chunks.html" : reqPath;
  const full = path.join(PUBLIC_DIR, rel.replace(/^\/+/, ""));
  if (!full.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }
  if (!fs.existsSync(full) || fs.statSync(full).isDirectory()) {
    res.writeHead(404);
    return res.end("Not found");
  }

  const ext = path.extname(full).toLowerCase();
  const ctype =
    ext === ".html"
      ? "text/html; charset=utf-8"
      : ext === ".css"
      ? "text/css; charset=utf-8"
      : ext === ".js"
      ? "application/javascript; charset=utf-8"
      : ext === ".svg"
      ? "image/svg+xml"
      : "application/octet-stream";

  res.writeHead(200, { "Content-Type": ctype });
  fs.createReadStream(full).pipe(res);
}

const server = http.createServer(async (req, res) => {
  const reqUrl = new URL(req.url, "http://127.0.0.1");

  if (req.method === "GET" && reqUrl.pathname === "/api/health") {
    return sendJson(res, 200, {
      status: "ok",
      project_id: cfg.project_id || cfg.compartment_ocid || "default-project",
      model_id: CHAT_MODEL,
      embedding_model: EMBEDDING_MODEL,
      region: cfg.region,
      chunk_chars: CHUNK_CHARS,
      auth_contexts: AUTH_CONTEXTS.map((c) => ({
        name: c.name,
        region: c.region,
        tenancy_ocid: c.tenancyOcid,
        compartment_ocid: c.compartmentOcid,
      })),
    });
  }

  if (req.method === "GET" && reqUrl.pathname === "/api/diag/model") {
    const d = await modelDiag();
    return sendJson(res, 200, d);
  }

  if (req.method === "GET" && reqUrl.pathname === "/api/conversations") {
    return sendJson(res, 200, listConversations());
  }

  if (req.method === "GET" && reqUrl.pathname.startsWith("/api/projects/") && reqUrl.pathname.endsWith("/conversations")) {
    const parts = reqUrl.pathname.split("/");
    const projectId = decodeURIComponent(parts[3] || "");
    return sendJson(res, 200, listConversationsByProject(projectId));
  }

  if (
    req.method === "GET" &&
    reqUrl.pathname.startsWith("/api/projects/") &&
    reqUrl.pathname.includes("/conversations/") &&
    reqUrl.pathname.endsWith("/messages")
  ) {
    const parts = reqUrl.pathname.split("/");
    const projectId = decodeURIComponent(parts[3] || "");
    const conversationId = decodeURIComponent(parts[5] || "");
    const messages = getConversationMessages(conversationId);
    const projectConversations = listConversationsByProject(projectId);
    const belongsToProject = projectConversations.some((c) => c.id === conversationId);
    if (!belongsToProject && !messages.length) {
      return sendJson(res, 404, { error: "conversation not found for project" });
    }
    return sendJson(res, 200, messages);
  }

  if (req.method === "GET" && reqUrl.pathname === "/api/debug/chunks") {
    const conversationId = String(reqUrl.searchParams.get("conversation_id") || "").trim();
    const query = String(reqUrl.searchParams.get("q") || "").trim();
    const limit = clampInt(reqUrl.searchParams.get("limit"), 1, 500, 200);
    const offset = clampInt(reqUrl.searchParams.get("offset"), 0, 50000, 0);
    const top = clampInt(reqUrl.searchParams.get("top"), 1, 100, 20);
    const includeVectors = String(reqUrl.searchParams.get("include_vectors") || "") === "1";

    const db = readVectorDb();
    const allChunks = conversationId
      ? db.chunks.filter((c) => c.conversation_id === conversationId)
      : db.chunks.slice();

    let queryEmbedding = null;
    if (query) {
      queryEmbedding = await createEmbedding(query);
    }

    let ranked = allChunks.map((chunk) => {
      const score = query
        ? queryEmbedding
          ? cosineSimilarity(queryEmbedding, chunk.embedding)
          : lexicalOverlapScore(query, chunk.text)
        : null;
      return { chunk, score };
    });

    if (query) {
      ranked = ranked.sort((a, b) => (b.score || -1) - (a.score || -1)).slice(0, top);
    } else {
      ranked = ranked.sort((a, b) => (a.chunk.created_at < b.chunk.created_at ? 1 : -1));
    }

    const page = ranked.slice(offset, offset + limit).map((r) => ({
      id: r.chunk.id,
      conversation_id: r.chunk.conversation_id,
      filename: r.chunk.filename,
      chunk_index: r.chunk.chunk_index,
      created_at: r.chunk.created_at,
      score: r.score,
      has_embedding: Array.isArray(r.chunk.embedding),
      vector_dim: Array.isArray(r.chunk.embedding) ? r.chunk.embedding.length : 0,
      vector_head: Array.isArray(r.chunk.embedding) ? r.chunk.embedding.slice(0, 12) : [],
      vector: includeVectors && Array.isArray(r.chunk.embedding) ? r.chunk.embedding : undefined,
      text: r.chunk.text,
      text_preview: String(r.chunk.text || "").slice(0, 260),
    }));

    return sendJson(res, 200, {
      conversation_id: conversationId || null,
      query: query || null,
      total_chunks: allChunks.length,
      returned: page.length,
      offset,
      limit,
      top,
      query_mode: query ? (queryEmbedding ? "semantic" : "lexical") : "none",
      items: page,
    });
  }

  if (req.method === "GET" && reqUrl.pathname === "/api/debug/conversations") {
    const chatDb = readChatDb();
    const vectorDb = readVectorDb();
    const chunkCountByConversation = new Map();
    for (const c of vectorDb.chunks) {
      chunkCountByConversation.set(c.conversation_id, (chunkCountByConversation.get(c.conversation_id) || 0) + 1);
    }
    const docCountByConversation = new Map();
    for (const d of vectorDb.documents) {
      docCountByConversation.set(d.conversation_id, (docCountByConversation.get(d.conversation_id) || 0) + 1);
    }

    const items = chatDb.conversations
      .map((c) => ({
        id: c.id,
        title: c.title,
        created_at: c.created_at,
        docs: docCountByConversation.get(c.id) || 0,
        chunks: chunkCountByConversation.get(c.id) || 0,
      }))
      .sort((a, b) => (a.created_at < b.created_at ? 1 : -1));

    return sendJson(res, 200, items);
  }

  if (req.method === "POST" && reqUrl.pathname === "/api/debug/clear-vectors") {
    const vectorDb = readVectorDb();
    const cleared = {
      documents: vectorDb.documents.length,
      chunks: vectorDb.chunks.length,
    };
    writeVectorDb({ documents: [], chunks: [] });
    return sendJson(res, 200, {
      status: "ok",
      cleared,
      remaining: { documents: 0, chunks: 0 },
    });
  }

  if (req.method === "POST" && reqUrl.pathname === "/api/conversations/new") {
    const body = await parseBody(req);
    const conversationId = randomConversationId();
    upsertConversation(conversationId, body.title || "Nova conversa", cfg.project_id || "default-project");
    return sendJson(res, 200, { conversation_id: conversationId, remote_conversation: false });
  }

  if (req.method === "GET" && reqUrl.pathname.startsWith("/api/conversations/") && reqUrl.pathname.endsWith("/messages")) {
    const parts = reqUrl.pathname.split("/");
    const conversationId = decodeURIComponent(parts[3] || "");
    return sendJson(res, 200, getConversationMessages(conversationId));
  }

  if (req.method === "GET" && reqUrl.pathname.startsWith("/api/conversations/") && reqUrl.pathname.endsWith("/documents")) {
    const parts = reqUrl.pathname.split("/");
    const conversationId = decodeURIComponent(parts[3] || "");
    return sendJson(res, 200, listKnowledgeDocs(conversationId));
  }

  if (req.method === "POST" && reqUrl.pathname === "/api/files/upload") {
    const body = await parseBody(req);
    try {
      const result = await ingestDocument({
        conversationId: String(body.conversation_id || "").trim(),
        filename: String(body.filename || "").trim(),
        mimeType: String(body.mime_type || "").trim(),
        content: String(body.content || ""),
        contentBase64: String(body.content_base64 || ""),
      });
      return sendJson(res, 200, result);
    } catch (err) {
      return sendJson(res, 400, { error: String(err.message || err) });
    }
  }

  if (req.method === "POST" && reqUrl.pathname === "/api/chat") {
    const body = await parseBody(req);
    const conversationId = String(body.conversation_id || "").trim();
    const message = String(body.message || "").trim();
    const useKnowledge = !!body.use_knowledge;
    const useWebSearch = !!body.use_web_search;

    if (!conversationId) return sendJson(res, 400, { error: "conversation_id is required" });
    if (!message) return sendJson(res, 400, { error: "message is required" });

    upsertConversation(conversationId, message.slice(0, 60), cfg.project_id || "default-project");
    addMessage(conversationId, "user", message);

    const agentOut = await runLangChainAgent({
      conversationId,
      message,
      allowKnowledge: useKnowledge,
      allowWebSearch: useWebSearch,
    });
    const assistantMessage = agentOut.answer;

    const metadata = {
      use_knowledge: useKnowledge,
      use_web_search: useWebSearch,
      model_ok: agentOut.ok,
      model_endpoint: agentOut.model_endpoint,
      model_context: agentOut.model_context,
      attempts: agentOut.attempts,
      tool_trace: agentOut.toolTrace,
    };

    addMessage(conversationId, "assistant", assistantMessage, metadata);
    return sendJson(res, 200, {
      conversation_id: conversationId,
      assistant_message: assistantMessage,
      metadata,
    });
  }

  if (req.method === "POST" && reqUrl.pathname === "/api/chat/stream") {
    const body = await parseBody(req);
    const conversationId = String(body.conversation_id || "").trim();
    const message = String(body.message || "").trim();
    const useKnowledge = !!body.use_knowledge;
    const useWebSearch = !!body.use_web_search;

    if (!conversationId) return sendJson(res, 400, { error: "conversation_id is required" });
    if (!message) return sendJson(res, 400, { error: "message is required" });

    res.writeHead(200, {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    });

    const sendEvent = (event, data) => {
      res.write(`event: ${event}\n`);
      res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    try {
      upsertConversation(conversationId, message.slice(0, 60), cfg.project_id || "default-project");
      addMessage(conversationId, "user", message);

      const agentOut = await runLangChainAgent({
        conversationId,
        message,
        allowKnowledge: useKnowledge,
        allowWebSearch: useWebSearch,
      });

      const assistantMessage = agentOut.answer;
      for (const part of chunkForPseudoStream(assistantMessage)) {
        sendEvent("delta", { text: part });
      }

      const metadata = {
        use_knowledge: useKnowledge,
        use_web_search: useWebSearch,
        model_ok: agentOut.ok,
        model_endpoint: agentOut.model_endpoint,
        model_context: agentOut.model_context,
        attempts: agentOut.attempts,
        tool_trace: agentOut.toolTrace,
      };

      addMessage(conversationId, "assistant", assistantMessage, metadata);
      sendEvent("done", {
        conversation_id: conversationId,
        assistant_message: assistantMessage,
        metadata,
      });
      return res.end();
    } catch (err) {
      sendEvent("error", { error: String(err.message || err) });
      return res.end();
    }
  }

  if (req.method === "GET" || req.method === "HEAD") return serveStatic(req, res);

  res.writeHead(404);
  res.end("Not found");
});

ensureDataFiles();
server.listen(PORT, BIND_HOST, () => {
  console.log(`Server running on http://${BIND_HOST}:${PORT}`);
});
