variable "region" {
  description = "OCI region (ex.: sa-saopaulo-1, us-chicago-1)."
  type        = string
}

variable "model" {
  description = "Model ID usado pela aplicacao (ex.: meta.llama-3.3-70b-instruct)."
  type        = string
}

variable "tenancy_ocid" {
  description = "Tenancy OCID. Em OCI Resource Manager normalmente vem do contexto do stack."
  type        = string
  default     = ""
}

variable "compartment_ocid" {
  description = "Compartment OCID para recursos da aplicacao. Se vazio, usa tenancy_ocid."
  type        = string
  default     = ""
}

variable "ssh_public_key" {
  description = "Chave SSH publica opcional. Se vazio, Terraform gera um par e exporta a chave privada em output sensivel."
  type        = string
  default     = ""
}

variable "expose_private_outputs" {
  description = "Se true, exibe chaves privadas nos outputs. Recomenda-se manter false."
  type        = bool
  default     = false
}
